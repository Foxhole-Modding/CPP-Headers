#ifndef UE4SS_SDK_BPCamouflageTent_HPP
#define UE4SS_SDK_BPCamouflageTent_HPP

class ABPCamouflageTent_C : public AActor
{
    class UStaticMeshComponent* Tarp01;
    class UStaticMeshComponent* StaticMesh4;
    class UStaticMeshComponent* AmmoCrate;
    class UStaticMeshComponent* AmmoCrateTop;
    class UStaticMeshComponent* StaticMesh3;
    class UStaticMeshComponent* StaticMesh2;
    class UStaticMeshComponent* StaticMesh1;
    class UStaticMeshComponent* StaticMesh;
    class UStaticMeshComponent* Rug05;
    class UStaticMeshComponent* Rug07;
    class UStaticMeshComponent* FuelPickup;
    class UStaticMeshComponent* CarbinePickup;
    class UStaticMeshComponent* Candles1;
    class UStaticMeshComponent* CrateGrey;
    class UStaticMeshComponent* ClothTent01;
    class USceneComponent* DefaultSceneRoot;

};

#endif
