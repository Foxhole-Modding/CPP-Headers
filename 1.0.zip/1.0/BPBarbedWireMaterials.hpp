#ifndef UE4SS_SDK_BPBarbedWireMaterials_HPP
#define UE4SS_SDK_BPBarbedWireMaterials_HPP

class ABPBarbedWireMaterials_C : public AGearPickup
{
    class USkeletalMeshComponent* ItemMeshSK;

};

#endif
