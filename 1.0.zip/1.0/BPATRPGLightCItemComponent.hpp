#ifndef UE4SS_SDK_BPATRPGLightCItemComponent_HPP
#define UE4SS_SDK_BPATRPGLightCItemComponent_HPP

class UBPATRPGLightCItemComponent_C : public UBPATRPGCItemComponent_C
{
};

#endif
