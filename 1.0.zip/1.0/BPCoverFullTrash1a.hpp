#ifndef UE4SS_SDK_BPCoverFullTrash1a_HPP
#define UE4SS_SDK_BPCoverFullTrash1a_HPP

class ABPCoverFullTrash1a_C : public AActor
{
    class UDecalComponent* Decal;
    class UStaticMeshComponent* StaticMesh;
    class USceneComponent* Default Scene Root;

};

#endif
