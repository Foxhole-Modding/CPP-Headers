#ifndef UE4SS_SDK_BPATRPGCProjectile_HPP
#define UE4SS_SDK_BPATRPGCProjectile_HPP

class ABPATRPGCProjectile_C : public AWarProjectile
{
    class UStaticMeshComponent* Mesh;

};

#endif
