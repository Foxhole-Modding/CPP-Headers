#ifndef UE4SS_SDK_BPCoverStreetlamp1c_HPP
#define UE4SS_SDK_BPCoverStreetlamp1c_HPP

class ABPCoverStreetlamp1c_C : public AActor
{
    class UDecalComponent* Decal;
    class UStaticMeshComponent* StaticMesh;
    class USceneComponent* Default Scene Root;
    class USpotLightComponent* SpotLight;

};

#endif
