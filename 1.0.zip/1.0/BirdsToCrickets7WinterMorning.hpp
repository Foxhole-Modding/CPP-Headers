#ifndef UE4SS_SDK_BirdsToCrickets7WinterMorning_HPP
#define UE4SS_SDK_BirdsToCrickets7WinterMorning_HPP

class ABirdsToCrickets7WinterMorning_C : public AEnvironmentSFX
{
};

#endif
