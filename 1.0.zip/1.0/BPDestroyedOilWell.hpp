#ifndef UE4SS_SDK_BPDestroyedOilWell_HPP
#define UE4SS_SDK_BPDestroyedOilWell_HPP

class ABPDestroyedOilWell_C : public ADestroyedResourceMine
{
    class UBoxComponent* Box2;
    class UBoxComponent* Box1;
    class UBoxComponent* Box;
    class UDecalComponent* Decal;
    class UStaticMeshComponent* StaticMesh;

};

#endif
