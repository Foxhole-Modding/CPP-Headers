#ifndef UE4SS_SDK_BPConstructionVehicleProxyGhost_HPP
#define UE4SS_SDK_BPConstructionVehicleProxyGhost_HPP

class ABPConstructionVehicleProxyGhost_C : public ABuildGhost
{
    class USkeletalMeshComponent* SkeletalMesh;

};

#endif
