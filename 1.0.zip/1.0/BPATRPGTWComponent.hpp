#ifndef UE4SS_SDK_BPATRPGTWComponent_HPP
#define UE4SS_SDK_BPATRPGTWComponent_HPP

class UBPATRPGTWComponent_C : public UDeployableItemComponent
{
};

#endif
