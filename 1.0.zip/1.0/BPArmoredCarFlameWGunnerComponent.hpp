#ifndef UE4SS_SDK_BPArmoredCarFlameWGunnerComponent_HPP
#define UE4SS_SDK_BPArmoredCarFlameWGunnerComponent_HPP

class UBPArmoredCarFlameWGunnerComponent_C : public UBPFlameMountBaseComponent_C
{
};

#endif
