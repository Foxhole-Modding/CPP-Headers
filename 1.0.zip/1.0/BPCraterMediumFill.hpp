#ifndef UE4SS_SDK_BPCraterMediumFill_HPP
#define UE4SS_SDK_BPCraterMediumFill_HPP

class ABPCraterMediumFill_C : public ABPCraterMedium_C
{
};

#endif
