#ifndef UE4SS_SDK_BPATRifleAmmoPickup_HPP
#define UE4SS_SDK_BPATRifleAmmoPickup_HPP

class ABPATRifleAmmoPickup_C : public AAmmoPickup
{
};

#endif
