#ifndef UE4SS_SDK_BPDeployedMGTW_HPP
#define UE4SS_SDK_BPDeployedMGTW_HPP

class ABPDeployedMGTW_C : public ADeployedWeapon
{
    class UMultiplexedStaticMeshComponent* MultiplexedStaticMesh;

};

#endif
