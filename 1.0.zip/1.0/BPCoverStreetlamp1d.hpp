#ifndef UE4SS_SDK_BPCoverStreetlamp1d_HPP
#define UE4SS_SDK_BPCoverStreetlamp1d_HPP

class ABPCoverStreetlamp1d_C : public AActor
{
    class USpotLightComponent* SpotLight1;
    class UDecalComponent* Decal;
    class UStaticMeshComponent* StaticMesh;
    class USceneComponent* Default Scene Root;

};

#endif
