#ifndef UE4SS_SDK_BPDestroyerTankW_HPP
#define UE4SS_SDK_BPDestroyerTankW_HPP

class ABPDestroyerTankW_C : public ABPDestroyerTankBaseW_C
{
};

#endif
