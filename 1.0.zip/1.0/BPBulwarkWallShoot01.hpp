#ifndef UE4SS_SDK_BPBulwarkWallShoot01_HPP
#define UE4SS_SDK_BPBulwarkWallShoot01_HPP

class ABPBulwarkWallShoot01_C : public AActor
{
    class UBoxComponent* Box;
    class UStaticMeshComponent* sandbag01;
    class UBPStructureInteriorArea_C* BPStructureInteriorArea;
    class UStaticMeshComponent* BulwarkWallRoof;
    class UStaticMeshComponent* BulwarkWallBase02;
    class USceneComponent* DefaultSceneRoot;

};

#endif
