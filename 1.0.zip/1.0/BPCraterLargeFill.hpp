#ifndef UE4SS_SDK_BPCraterLargeFill_HPP
#define UE4SS_SDK_BPCraterLargeFill_HPP

class ABPCraterLargeFill_C : public ABPCraterLarge_C
{
};

#endif
