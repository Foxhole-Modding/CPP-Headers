#ifndef UE4SS_SDK_BPBinocularsComponent_HPP
#define UE4SS_SDK_BPBinocularsComponent_HPP

class UBPBinocularsComponent_C : public UBinocularsItemComponent
{
};

#endif
