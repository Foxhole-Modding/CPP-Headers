#ifndef UE4SS_SDK_BinocularsPickup_HPP
#define UE4SS_SDK_BinocularsPickup_HPP

class ABinocularsPickup_C : public AGearPickup
{
    class UStaticMeshComponent* BinocularPickup;

};

#endif
