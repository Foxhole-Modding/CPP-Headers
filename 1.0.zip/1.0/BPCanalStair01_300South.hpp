#ifndef UE4SS_SDK_BPCanalStair01_300South_HPP
#define UE4SS_SDK_BPCanalStair01_300South_HPP

class ABPCanalStair01_300South_C : public AActor
{
    class UStaticMeshComponent* StaticMesh;
    class USceneComponent* Scene;

};

#endif
