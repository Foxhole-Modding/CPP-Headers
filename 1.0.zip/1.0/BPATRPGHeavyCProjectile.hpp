#ifndef UE4SS_SDK_BPATRPGHeavyCProjectile_HPP
#define UE4SS_SDK_BPATRPGHeavyCProjectile_HPP

class ABPATRPGHeavyCProjectile_C : public ABPATRPGCProjectile_C
{
};

#endif
