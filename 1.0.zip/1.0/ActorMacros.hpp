#ifndef UE4SS_SDK_ActorMacros_HPP
#define UE4SS_SDK_ActorMacros_HPP

class AActorMacros_C : public AActor
{
};

#endif
