#ifndef UE4SS_SDK_BPCoverWallStreetcar1c_HPP
#define UE4SS_SDK_BPCoverWallStreetcar1c_HPP

class ABPCoverWallStreetcar1c_C : public AActor
{
    class UStaticMeshComponent* CoverWallStreetcar1;
    class USceneComponent* DefaultSceneRoot;

};

#endif
