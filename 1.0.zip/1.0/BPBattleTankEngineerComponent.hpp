#ifndef UE4SS_SDK_BPBattleTankEngineerComponent_HPP
#define UE4SS_SDK_BPBattleTankEngineerComponent_HPP

class UBPBattleTankEngineerComponent_C : public UTankEngineerComponent
{
};

#endif
