#ifndef UE4SS_SDK_BPBulwarkWallShoot02_HPP
#define UE4SS_SDK_BPBulwarkWallShoot02_HPP

class ABPBulwarkWallShoot02_C : public AActor
{
    class UBoxComponent* Box;
    class UStaticMeshComponent* StaticMesh32;
    class UStaticMeshComponent* StaticMesh31;
    class UStaticMeshComponent* StaticMesh30;
    class UStaticMeshComponent* StaticMesh29;
    class UStaticMeshComponent* StaticMesh28;
    class UStaticMeshComponent* StaticMesh27;
    class UStaticMeshComponent* StaticMesh10;
    class UStaticMeshComponent* StaticMesh26;
    class UStaticMeshComponent* StaticMesh25;
    class UStaticMeshComponent* StaticMesh24;
    class UStaticMeshComponent* StaticMesh22;
    class UStaticMeshComponent* StaticMesh23;
    class UStaticMeshComponent* StaticMesh21;
    class UStaticMeshComponent* StaticMesh20;
    class UStaticMeshComponent* StaticMesh19;
    class UStaticMeshComponent* StaticMesh18;
    class UStaticMeshComponent* WetlandsWalkwayPlanks03;
    class UStaticMeshComponent* StaticMesh16;
    class UStaticMeshComponent* StaticMesh17;
    class UStaticMeshComponent* StaticMesh15;
    class UStaticMeshComponent* StaticMesh14;
    class UStaticMeshComponent* StaticMesh13;
    class UStaticMeshComponent* WoodOldPillarSquare;
    class UStaticMeshComponent* StaticMesh12;
    class UStaticMeshComponent* StaticMesh9;
    class UStaticMeshComponent* StaticMesh11;
    class UStaticMeshComponent* StaticMesh8;
    class UStaticMeshComponent* StaticMesh7;
    class UStaticMeshComponent* StaticMesh6;
    class UStaticMeshComponent* WoodBeam01;
    class UStaticMeshComponent* StaticMesh3;
    class UStaticMeshComponent* StaticMesh2;
    class UStaticMeshComponent* StaticMesh5;
    class UStaticMeshComponent* StaticMesh4;
    class UStaticMeshComponent* StaticMesh1;
    class UStaticMeshComponent* StaticMesh;
    class UStaticMeshComponent* CrateGrey;
    class UStaticMeshComponent* AmmoCrateTop;
    class UStaticMeshComponent* AmmoCrate;
    class UStaticMeshComponent* BulwarkWallRoof2;
    class UStaticMeshComponent* sandbag01;
    class UBPStructureInteriorArea_C* BPStructureInteriorArea;
    class UStaticMeshComponent* BulwarkWallRoof;
    class UStaticMeshComponent* BulwarkWallBase02;
    class USceneComponent* DefaultSceneRoot;

};

#endif
