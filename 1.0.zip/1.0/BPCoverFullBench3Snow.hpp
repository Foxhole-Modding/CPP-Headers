#ifndef UE4SS_SDK_BPCoverFullBench3Snow_HPP
#define UE4SS_SDK_BPCoverFullBench3Snow_HPP

class ABPCoverFullBench3Snow_C : public AActor
{
    class UDecalComponent* Decal;
    class UStaticMeshComponent* StaticMesh;
    class USceneComponent* Default Scene Root;

};

#endif
