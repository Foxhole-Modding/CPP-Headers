#ifndef UE4SS_SDK_BPDestroyedShipyard_HPP
#define UE4SS_SDK_BPDestroyedShipyard_HPP

class ABPDestroyedShipyard_C : public ADestroyedVehicleFactory
{
    class UStaticMeshComponent* StaticMesh;

};

#endif
