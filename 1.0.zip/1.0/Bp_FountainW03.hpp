#ifndef UE4SS_SDK_Bp_FountainW03_HPP
#define UE4SS_SDK_Bp_FountainW03_HPP

class ABp_FountainW03_C : public AActor
{
    class UDecalComponent* W;
    class UDecalComponent* Dirt Decal4;
    class UDecalComponent* Dirt Decal2;
    class UDecalComponent* Dirt Decal3;
    class UDecalComponent* GourndFloor;
    class UDecalComponent* Dirtside5;
    class UDecalComponent* Dirtside4;
    class UDecalComponent* Dirtside3;
    class UDecalComponent* Dirtside2;
    class UDecalComponent* RustFromPipe1;
    class UDecalComponent* Dirt Decal1;
    class UDecalComponent* RustFromPipe;
    class UDecalComponent* Leaves;
    class UDecalComponent* Dirt Decal;
    class UStaticMeshComponent* FountainC01;
    class USceneComponent* DefaultSceneRoot;

};

#endif
