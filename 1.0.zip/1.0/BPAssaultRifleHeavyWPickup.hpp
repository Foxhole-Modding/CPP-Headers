#ifndef UE4SS_SDK_BPAssaultRifleHeavyWPickup_HPP
#define UE4SS_SDK_BPAssaultRifleHeavyWPickup_HPP

class ABPAssaultRifleHeavyWPickup_C : public AFirearmPickup
{
};

#endif
