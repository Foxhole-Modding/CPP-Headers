#ifndef UE4SS_SDK_BasicLadderVines_HPP
#define UE4SS_SDK_BasicLadderVines_HPP

class ABasicLadderVines_C : public ALadder
{
    class UStaticMeshComponent* StaticMesh;

};

#endif
