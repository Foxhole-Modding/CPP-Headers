#ifndef UE4SS_SDK_BPDestroyedRVWallT1_HPP
#define UE4SS_SDK_BPDestroyedRVWallT1_HPP

class ABPDestroyedRVWallT1_C : public ADestroyedStructure
{
    class UStaticMeshComponent* StaticMesh;

};

#endif
