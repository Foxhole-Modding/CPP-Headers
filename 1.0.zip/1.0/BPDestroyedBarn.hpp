#ifndef UE4SS_SDK_BPDestroyedBarn_HPP
#define UE4SS_SDK_BPDestroyedBarn_HPP

class ABPDestroyedBarn_C : public ADestroyedGarrisonHouse
{
    class URuinedMeshComponent* w1;
    class URuinedMeshComponent* W;
    class URuinedMeshComponent* RuinedMesh3;
    class URuinedMeshComponent* RuinedMesh2;
    class URuinedMeshComponent* RuinedMesh1;
    class URuinedMeshComponent* RuinedMesh;
    class UBPStructureInteriorArea_C* BPStructureInteriorArea;
    class UStaticMeshComponent* StaticMesh2;
    class UDecalComponent* Decal2;
    class UDecalComponent* Decal1;
    class UDecalComponent* Decal;
    class UStaticMeshComponent* StaticMesh1;
    class UStaticMeshComponent* StaticMesh;
    class UStaticMeshComponent* HouseMesh;

};

#endif
