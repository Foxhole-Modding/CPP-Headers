#ifndef UE4SS_SDK_BPCraneMarker_HPP
#define UE4SS_SDK_BPCraneMarker_HPP

class ABPCraneMarker_C : public ACraneMarker
{
};

#endif
