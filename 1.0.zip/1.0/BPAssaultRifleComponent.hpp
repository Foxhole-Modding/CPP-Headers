#ifndef UE4SS_SDK_BPAssaultRifleComponent_HPP
#define UE4SS_SDK_BPAssaultRifleComponent_HPP

class UBPAssaultRifleComponent_C : public UAssaultRifleComponent
{
};

#endif
