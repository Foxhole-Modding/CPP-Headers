#ifndef UE4SS_SDK_BandagesComponent_HPP
#define UE4SS_SDK_BandagesComponent_HPP

class UBandagesComponent_C : public UBandagesComponent
{
};

#endif
