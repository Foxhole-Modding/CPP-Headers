#ifndef UE4SS_SDK_BPBattleTankAmmo_HPP
#define UE4SS_SDK_BPBattleTankAmmo_HPP

class UBPBattleTankAmmo_C : public ULargeItemComponent
{
};

#endif
