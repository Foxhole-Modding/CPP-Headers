#ifndef UE4SS_SDK_BPCoverWallStreetcar1a_HPP
#define UE4SS_SDK_BPCoverWallStreetcar1a_HPP

class ABPCoverWallStreetcar1a_C : public AActor
{
    class UStaticMeshComponent* CoverWallStreetcar1a;
    class USceneComponent* DefaultSceneRoot;

};

#endif
