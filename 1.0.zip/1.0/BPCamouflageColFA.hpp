#ifndef UE4SS_SDK_BPCamouflageColFA_HPP
#define UE4SS_SDK_BPCamouflageColFA_HPP

class ABPCamouflageColFA_C : public AActor
{
    class UStaticMeshComponent* FieldArtilleryColDestroyed;
    class UStaticMeshComponent* CamouflageColFA;
    class USceneComponent* DefaultSceneRoot;

};

#endif
