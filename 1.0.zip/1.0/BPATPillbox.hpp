#ifndef UE4SS_SDK_BPATPillbox_HPP
#define UE4SS_SDK_BPATPillbox_HPP

class ABPATPillbox_C : public AFoxholeTurret
{
    class UMultiplexedStaticMeshComponent* MultiplexedStaticMesh;
    class UStaticMeshComponent* ATPillbox;

};

#endif
