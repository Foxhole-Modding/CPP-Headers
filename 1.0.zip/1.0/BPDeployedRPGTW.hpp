#ifndef UE4SS_SDK_BPDeployedRPGTW_HPP
#define UE4SS_SDK_BPDeployedRPGTW_HPP

class ABPDeployedRPGTW_C : public ADeployedWeapon
{
    class UMultiplexedStaticMeshComponent* MultiplexedStaticMesh;

};

#endif
