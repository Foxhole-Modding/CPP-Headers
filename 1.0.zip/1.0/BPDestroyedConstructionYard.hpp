#ifndef UE4SS_SDK_BPDestroyedConstructionYard_HPP
#define UE4SS_SDK_BPDestroyedConstructionYard_HPP

class ABPDestroyedConstructionYard_C : public ADestroyedConstructionSite
{
    class UStaticMeshComponent* StaticMesh19;
    class UStaticMeshComponent* StaticMesh18;
    class UStaticMeshComponent* StaticMesh17;
    class UStaticMeshComponent* StaticMesh16;
    class UStaticMeshComponent* StaticMesh15;
    class UStaticMeshComponent* StaticMesh14;
    class UStaticMeshComponent* StaticMesh13;
    class UStaticMeshComponent* StaticMesh12;
    class UStaticMeshComponent* StaticMesh11;
    class UStaticMeshComponent* StaticMesh10;
    class UStaticMeshComponent* StaticMesh9;
    class UStaticMeshComponent* StaticMesh8;
    class UStaticMeshComponent* StaticMesh7;
    class UStaticMeshComponent* StaticMesh6;
    class UStaticMeshComponent* StaticMesh5;
    class UDecalComponent* Decal7;
    class UStaticMeshComponent* StaticMesh4;
    class UDecalComponent* Decal6;
    class UDecalComponent* Decal5;
    class UDecalComponent* Decal4;
    class UDecalComponent* Decal3;
    class UDecalComponent* Decal2;
    class UDecalComponent* Decal1;
    class UStaticMeshComponent* StaticMesh3;
    class UStaticMeshComponent* StaticMesh2;
    class UStaticMeshComponent* StaticMesh1;
    class UDecalComponent* Decal;
    class UStaticMeshComponent* ConstructionYardDestroyed;
    class UStaticMeshComponent* StaticMesh;

};

#endif
