#ifndef UE4SS_SDK_BPArmourPiercingNoBonusesDamageType_HPP
#define UE4SS_SDK_BPArmourPiercingNoBonusesDamageType_HPP

class UBPArmourPiercingNoBonusesDamageType_C : public USimDamageType
{
};

#endif
