#ifndef UE4SS_SDK_BirdsToCricketsRockySurf_Cue_HPP
#define UE4SS_SDK_BirdsToCricketsRockySurf_Cue_HPP

class ABirdsToCricketsRockySurf_Cue_C : public AEnvironmentSFX
{
};

#endif
