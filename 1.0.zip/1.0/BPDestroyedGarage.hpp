#ifndef UE4SS_SDK_BPDestroyedGarage_HPP
#define UE4SS_SDK_BPDestroyedGarage_HPP

class ABPDestroyedGarage_C : public ADestroyedStorageFacility
{
    class UDecalComponent* Decal;
    class UStaticMeshComponent* StorageFaciltyDestoryed;

};

#endif
