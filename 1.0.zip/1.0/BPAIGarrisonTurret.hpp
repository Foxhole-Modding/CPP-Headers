#ifndef UE4SS_SDK_BPAIGarrisonTurret_HPP
#define UE4SS_SDK_BPAIGarrisonTurret_HPP

class UBPAIGarrisonTurret_C : public UAITurretComponent
{
};

#endif
