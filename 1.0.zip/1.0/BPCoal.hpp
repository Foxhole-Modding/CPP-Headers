#ifndef UE4SS_SDK_BPCoal_HPP
#define UE4SS_SDK_BPCoal_HPP

class ABPCoal_C : public ABasicItemPickup
{
};

#endif
