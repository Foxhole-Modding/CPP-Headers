#ifndef UE4SS_SDK_BPAluminum_HPP
#define UE4SS_SDK_BPAluminum_HPP

class ABPAluminum_C : public ABasicItemPickup
{
};

#endif
