#ifndef UE4SS_SDK_BPDestroyedScrapMine_HPP
#define UE4SS_SDK_BPDestroyedScrapMine_HPP

class ABPDestroyedScrapMine_C : public ADestroyedResourceMine
{
    class UDecalComponent* Decal;
    class UBoxComponent* Box3;
    class UBoxComponent* Box2;
    class UBoxComponent* Box1;
    class UBoxComponent* Box;
    class UStaticMeshComponent* StaticMesh;

};

#endif
