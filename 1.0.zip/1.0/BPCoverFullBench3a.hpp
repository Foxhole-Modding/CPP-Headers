#ifndef UE4SS_SDK_BPCoverFullBench3a_HPP
#define UE4SS_SDK_BPCoverFullBench3a_HPP

class ABPCoverFullBench3a_C : public AActor
{
    class UDecalComponent* Decal;
    class UStaticMeshComponent* StaticMesh;
    class USceneComponent* Default Scene Root;

};

#endif
