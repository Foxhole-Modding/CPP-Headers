#ifndef UE4SS_SDK_BPArmourPiercingDamageType_HPP
#define UE4SS_SDK_BPArmourPiercingDamageType_HPP

class UBPArmourPiercingDamageType_C : public USimDamageType
{
};

#endif
