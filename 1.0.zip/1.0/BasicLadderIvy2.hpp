#ifndef UE4SS_SDK_BasicLadderIvy2_HPP
#define UE4SS_SDK_BasicLadderIvy2_HPP

class ABasicLadderIvy2_C : public ALadder
{
    class UStaticMeshComponent* StaticMesh4;
    class UStaticMeshComponent* StaticMesh3;
    class UStaticMeshComponent* StaticMesh2;
    class UStaticMeshComponent* StaticMesh1;

};

#endif
