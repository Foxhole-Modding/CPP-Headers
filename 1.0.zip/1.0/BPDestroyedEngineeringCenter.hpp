#ifndef UE4SS_SDK_BPDestroyedEngineeringCenter_HPP
#define UE4SS_SDK_BPDestroyedEngineeringCenter_HPP

class ABPDestroyedEngineeringCenter_C : public ADestroyedSpecializedFactory
{
    class UDecalComponent* Decal;
    class UStaticMeshComponent* EngineeringCenter;

};

#endif
