#ifndef UE4SS_SDK_BirdsToCrickets4_Cue_HPP
#define UE4SS_SDK_BirdsToCrickets4_Cue_HPP

class ABirdsToCrickets4_Cue_C : public AEnvironmentSFX
{
};

#endif
