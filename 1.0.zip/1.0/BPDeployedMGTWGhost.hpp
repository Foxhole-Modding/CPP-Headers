#ifndef UE4SS_SDK_BPDeployedMGTWGhost_HPP
#define UE4SS_SDK_BPDeployedMGTWGhost_HPP

class ABPDeployedMGTWGhost_C : public ABuildGhost
{
    class UBuildSocketComponent* BuildSocket;
    class USkeletalMeshComponent* SkeletalMesh1;
    class UStaticMeshComponent* StaticMesh;
    class USkeletalMeshComponent* SkeletalMesh;

};

#endif
