#ifndef UE4SS_SDK_BPCoverWallKiosk1_HPP
#define UE4SS_SDK_BPCoverWallKiosk1_HPP

class ABPCoverWallKiosk1_C : public AActor
{
    class UStaticMeshComponent* StaticMesh5;
    class UStaticMeshComponent* StaticMesh4;
    class UStaticMeshComponent* StaticMesh3;
    class UStaticMeshComponent* Paper2;
    class UStaticMeshComponent* Paper03;
    class UStaticMeshComponent* PropagandaPosterWarV2;
    class UStaticMeshComponent* StaticMesh2;
    class UStaticMeshComponent* StaticMesh1;
    class UStaticMeshComponent* Paper02;
    class UStaticMeshComponent* StaticMesh;
    class USceneComponent* Default Scene Root;

};

#endif
