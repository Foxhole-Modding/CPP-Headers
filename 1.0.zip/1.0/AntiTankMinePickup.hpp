#ifndef UE4SS_SDK_AntiTankMinePickup_HPP
#define UE4SS_SDK_AntiTankMinePickup_HPP

class AAntiTankMinePickup_C : public AGearPickup
{
};

#endif
