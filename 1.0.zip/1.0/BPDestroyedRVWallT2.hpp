#ifndef UE4SS_SDK_BPDestroyedRVWallT2_HPP
#define UE4SS_SDK_BPDestroyedRVWallT2_HPP

class ABPDestroyedRVWallT2_C : public ADestroyedStructure
{
    class UStaticMeshComponent* StaticMesh;

};

#endif
