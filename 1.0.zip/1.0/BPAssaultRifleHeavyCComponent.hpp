#ifndef UE4SS_SDK_BPAssaultRifleHeavyCComponent_HPP
#define UE4SS_SDK_BPAssaultRifleHeavyCComponent_HPP

class UBPAssaultRifleHeavyCComponent_C : public UHeavyMachineGunItemComponent
{
};

#endif
