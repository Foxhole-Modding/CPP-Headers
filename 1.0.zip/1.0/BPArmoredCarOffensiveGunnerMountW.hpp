#ifndef UE4SS_SDK_BPArmoredCarOffensiveGunnerMountW_HPP
#define UE4SS_SDK_BPArmoredCarOffensiveGunnerMountW_HPP

class UBPArmoredCarOffensiveGunnerMountW_C : public UTankGunnerMountComponent
{
};

#endif
