#ifndef UE4SS_SDK_BPArmourUniformW_HPP
#define UE4SS_SDK_BPArmourUniformW_HPP

class ABPArmourUniformW_C : public ABPUniform_C
{
};

#endif
