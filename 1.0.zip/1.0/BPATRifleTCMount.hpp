#ifndef UE4SS_SDK_BPATRifleTCMount_HPP
#define UE4SS_SDK_BPATRifleTCMount_HPP

class UBPATRifleTCMount_C : public UHitScanMountComponent
{
};

#endif
