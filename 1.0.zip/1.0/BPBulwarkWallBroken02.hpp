#ifndef UE4SS_SDK_BPBulwarkWallBroken02_HPP
#define UE4SS_SDK_BPBulwarkWallBroken02_HPP

class ABPBulwarkWallBroken02_C : public AActor
{
    class UBoxComponent* Box;
    class UStaticMeshComponent* StaticMesh6;
    class UStaticMeshComponent* StaticMesh5;
    class UStaticMeshComponent* StaticMesh4;
    class UStaticMeshComponent* StaticMesh3;
    class UStaticMeshComponent* StaticMesh2;
    class UStaticMeshComponent* StaticMesh1;
    class UStaticMeshComponent* StaticMesh;
    class UStaticMeshComponent* BulwarkWallBase01;
    class USceneComponent* DefaultSceneRoot;

};

#endif
