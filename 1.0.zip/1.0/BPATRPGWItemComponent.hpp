#ifndef UE4SS_SDK_BPATRPGWItemComponent_HPP
#define UE4SS_SDK_BPATRPGWItemComponent_HPP

class UBPATRPGWItemComponent_C : public UBPATRPGCItemComponent_C
{
};

#endif
