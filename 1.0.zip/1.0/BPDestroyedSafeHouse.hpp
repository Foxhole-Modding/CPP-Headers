#ifndef UE4SS_SDK_BPDestroyedSafeHouse_HPP
#define UE4SS_SDK_BPDestroyedSafeHouse_HPP

class ABPDestroyedSafeHouse_C : public ADestroyedStructure
{
    class UStaticMeshComponent* Roof;
    class UStaticMeshComponent* StaticMesh;

};

#endif
