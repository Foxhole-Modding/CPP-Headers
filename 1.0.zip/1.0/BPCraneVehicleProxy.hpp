#ifndef UE4SS_SDK_BPCraneVehicleProxy_HPP
#define UE4SS_SDK_BPCraneVehicleProxy_HPP

class ABPCraneVehicleProxy_C : public ABuildableStructure
{
};

#endif
