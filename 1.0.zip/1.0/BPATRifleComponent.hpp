#ifndef UE4SS_SDK_BPATRifleComponent_HPP
#define UE4SS_SDK_BPATRifleComponent_HPP

class UBPATRifleComponent_C : public UATRifleComponent
{
};

#endif
