#ifndef UE4SS_SDK_BPBaseResourceLayout_HPP
#define UE4SS_SDK_BPBaseResourceLayout_HPP

class UBPBaseResourceLayout_C : public UItemGroupRenderData
{
};

#endif
