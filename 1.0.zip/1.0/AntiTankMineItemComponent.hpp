#ifndef UE4SS_SDK_AntiTankMineItemComponent_HPP
#define UE4SS_SDK_AntiTankMineItemComponent_HPP

class UAntiTankMineItemComponent_C : public UExplosiveItemComponent
{
};

#endif
