#ifndef UE4SS_SDK_BPCanalStair02_600Snow_HPP
#define UE4SS_SDK_BPCanalStair02_600Snow_HPP

class ABPCanalStair02_600Snow_C : public AActor
{
    class UStaticMeshComponent* StaticMesh;
    class USceneComponent* Scene;

};

#endif
