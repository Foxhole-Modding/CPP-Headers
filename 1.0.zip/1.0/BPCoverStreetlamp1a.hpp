#ifndef UE4SS_SDK_BPCoverStreetlamp1a_HPP
#define UE4SS_SDK_BPCoverStreetlamp1a_HPP

class ABPCoverStreetlamp1a_C : public AActor
{
    class UDecalComponent* Decal;
    class UStaticMeshComponent* StaticMesh;
    class USceneComponent* Default Scene Root;
    class UPointLightComponent* PointLight;

};

#endif
