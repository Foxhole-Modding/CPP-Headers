#ifndef UE4SS_SDK_BPDestroyedObservationTower_HPP
#define UE4SS_SDK_BPDestroyedObservationTower_HPP

class ABPDestroyedObservationTower_C : public ADestroyedStructure
{
    class UStaticMeshComponent* StaticMesh;

};

#endif
