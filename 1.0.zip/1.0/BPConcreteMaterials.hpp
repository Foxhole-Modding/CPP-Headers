#ifndef UE4SS_SDK_BPConcreteMaterials_HPP
#define UE4SS_SDK_BPConcreteMaterials_HPP

class ABPConcreteMaterials_C : public ABasicItemPickup
{
};

#endif
