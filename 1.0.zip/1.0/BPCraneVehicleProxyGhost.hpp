#ifndef UE4SS_SDK_BPCraneVehicleProxyGhost_HPP
#define UE4SS_SDK_BPCraneVehicleProxyGhost_HPP

class ABPCraneVehicleProxyGhost_C : public ABuildGhost
{
    class USkeletalMeshComponent* SkeletalMesh;

};

#endif
