#ifndef UE4SS_SDK_BPCriticalSoldierComponent_HPP
#define UE4SS_SDK_BPCriticalSoldierComponent_HPP

class UBPCriticalSoldierComponent_C : public USoldierItemComponent
{
};

#endif
