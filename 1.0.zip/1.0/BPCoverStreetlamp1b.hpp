#ifndef UE4SS_SDK_BPCoverStreetlamp1b_HPP
#define UE4SS_SDK_BPCoverStreetlamp1b_HPP

class ABPCoverStreetlamp1b_C : public AActor
{
    class UDecalComponent* Decal;
    class UStaticMeshComponent* StaticMesh;
    class USceneComponent* Default Scene Root;
    class UPointLightComponent* PointLight1;
    class UPointLightComponent* PointLight;

};

#endif
