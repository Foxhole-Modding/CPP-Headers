#ifndef UE4SS_SDK_BPDestroyedComponentMine_HPP
#define UE4SS_SDK_BPDestroyedComponentMine_HPP

class ABPDestroyedComponentMine_C : public ADestroyedResourceMine
{
    class UBoxComponent* Box7;
    class UBoxComponent* Box6;
    class UBoxComponent* Box5;
    class UBoxComponent* Box4;
    class UDecalComponent* Decal;
    class UStaticMeshComponent* StaticMesh;

};

#endif
