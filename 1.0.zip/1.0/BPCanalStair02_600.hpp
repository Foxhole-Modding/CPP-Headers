#ifndef UE4SS_SDK_BPCanalStair02_600_HPP
#define UE4SS_SDK_BPCanalStair02_600_HPP

class ABPCanalStair02_600_C : public AActor
{
    class UStaticMeshComponent* StaticMesh;
    class USceneComponent* Scene;

};

#endif
