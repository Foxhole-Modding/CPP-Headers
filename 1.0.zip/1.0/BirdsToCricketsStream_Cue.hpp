#ifndef UE4SS_SDK_BirdsToCricketsStream_Cue_HPP
#define UE4SS_SDK_BirdsToCricketsStream_Cue_HPP

class ABirdsToCricketsStream_Cue_C : public AEnvironmentSFX
{
};

#endif
