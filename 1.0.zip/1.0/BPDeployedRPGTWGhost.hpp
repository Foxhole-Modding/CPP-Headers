#ifndef UE4SS_SDK_BPDeployedRPGTWGhost_HPP
#define UE4SS_SDK_BPDeployedRPGTWGhost_HPP

class ABPDeployedRPGTWGhost_C : public ABuildGhost
{
    class UBuildSocketComponent* BuildSocket;
    class USkeletalMeshComponent* SkeletalMesh1;
    class UStaticMeshComponent* StaticMesh;
    class USkeletalMeshComponent* SkeletalMesh;

};

#endif
