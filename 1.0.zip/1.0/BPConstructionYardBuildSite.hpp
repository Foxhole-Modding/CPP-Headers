#ifndef UE4SS_SDK_BPConstructionYardBuildSite_HPP
#define UE4SS_SDK_BPConstructionYardBuildSite_HPP

class ABPConstructionYardBuildSite_C : public AConstructionSiteBuildSite
{
    class UStaticMeshComponent* StaticMesh22;
    class UStaticMeshComponent* StaticMesh21;
    class UStaticMeshComponent* StaticMesh20;
    class UStaticMeshComponent* StaticMesh19;
    class UStaticMeshComponent* StaticMesh18;
    class UStaticMeshComponent* StaticMesh17;
    class UStaticMeshComponent* StaticMesh16;
    class UStaticMeshComponent* StaticMesh15;
    class UStaticMeshComponent* StaticMesh14;
    class UStaticMeshComponent* StaticMesh13;
    class UStaticMeshComponent* StaticMesh12;
    class UStaticMeshComponent* StaticMesh11;
    class UStaticMeshComponent* StaticMesh10;
    class UStaticMeshComponent* StaticMesh9;
    class UStaticMeshComponent* StaticMesh8;
    class UStaticMeshComponent* StaticMesh1;
    class UStaticMeshComponent* StaticMesh2;
    class UStaticMeshComponent* StaticMesh7;
    class UStaticMeshComponent* StaticMesh6;
    class UStaticMeshComponent* StaticMesh5;
    class UStaticMeshComponent* StaticMesh4;
    class UStaticMeshComponent* StaticMesh3;
    class UStaticMeshComponent* StaticMesh;

};

#endif
