#ifndef UE4SS_SDK_BPBayonetPickup_HPP
#define UE4SS_SDK_BPBayonetPickup_HPP

class ABPBayonetPickup_C : public AAccessoryPickup
{
};

#endif
