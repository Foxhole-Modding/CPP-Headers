#ifndef UE4SS_SDK_BPDeployedATRifleTC_HPP
#define UE4SS_SDK_BPDeployedATRifleTC_HPP

class ABPDeployedATRifleTC_C : public ADeployedWeapon
{
    class UMultiplexedStaticMeshComponent* MultiplexedStaticMesh;

};

#endif
