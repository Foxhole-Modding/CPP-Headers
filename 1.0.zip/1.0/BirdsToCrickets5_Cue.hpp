#ifndef UE4SS_SDK_BirdsToCrickets5_Cue_HPP
#define UE4SS_SDK_BirdsToCrickets5_Cue_HPP

class ABirdsToCrickets5_Cue_C : public AEnvironmentSFX
{
};

#endif
