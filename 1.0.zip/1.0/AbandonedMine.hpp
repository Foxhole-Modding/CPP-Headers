#ifndef UE4SS_SDK_AbandonedMine_HPP
#define UE4SS_SDK_AbandonedMine_HPP

class AAbandonedMine_C : public AActor
{
    class UStaticMeshComponent* StaticMeshComponent025;
    class UStaticMeshComponent* StaticMeshComponent024;
    class UStaticMeshComponent* StaticMeshComponent023;
    class UStaticMeshComponent* StaticMeshComponent022;
    class UStaticMeshComponent* StaticMeshComponent021;
    class UStaticMeshComponent* StaticMeshComponent020;
    class UStaticMeshComponent* StaticMeshComponent019;
    class UStaticMeshComponent* StaticMeshComponent018;
    class UStaticMeshComponent* StaticMeshComponent017;
    class UStaticMeshComponent* StaticMeshComponent016;
    class UStaticMeshComponent* StaticMeshComponent015;
    class UStaticMeshComponent* StaticMeshComponent014;
    class UStaticMeshComponent* StaticMeshComponent013;
    class UStaticMeshComponent* StaticMeshComponent012;
    class UStaticMeshComponent* StaticMeshComponent011;
    class UStaticMeshComponent* StaticMeshComponent010;
    class UStaticMeshComponent* StaticMeshComponent09;
    class UStaticMeshComponent* StaticMeshComponent08;
    class UStaticMeshComponent* StaticMeshComponent07;
    class UStaticMeshComponent* StaticMeshComponent06;
    class UStaticMeshComponent* StaticMeshComponent05;
    class UStaticMeshComponent* StaticMeshComponent04;
    class UStaticMeshComponent* StaticMeshComponent03;
    class UStaticMeshComponent* StaticMeshComponent02;
    class UStaticMeshComponent* StaticMeshComponent01;
    class UStaticMeshComponent* Cairns2;
    class USceneComponent* DefaultSceneRoot1;
    class UStaticMeshComponent* StaticMeshComponent0;
    class USceneComponent* SharedRoot;

};

#endif
