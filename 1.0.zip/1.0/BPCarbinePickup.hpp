#ifndef UE4SS_SDK_BPCarbinePickup_HPP
#define UE4SS_SDK_BPCarbinePickup_HPP

class ABPCarbinePickup_C : public AFirearmPickup
{
};

#endif
