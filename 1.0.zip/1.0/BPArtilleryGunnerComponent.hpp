#ifndef UE4SS_SDK_BPArtilleryGunnerComponent_HPP
#define UE4SS_SDK_BPArtilleryGunnerComponent_HPP

class UBPArtilleryGunnerComponent_C : public UArtilleryGunnerMountComponent
{
};

#endif
