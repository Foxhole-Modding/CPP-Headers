#ifndef UE4SS_SDK_BPAssaultRifleAmmoPickup_HPP
#define UE4SS_SDK_BPAssaultRifleAmmoPickup_HPP

class ABPAssaultRifleAmmoPickup_C : public AAmmoPickup
{
};

#endif
