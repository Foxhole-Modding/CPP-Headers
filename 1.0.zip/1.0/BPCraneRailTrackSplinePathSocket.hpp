#ifndef UE4SS_SDK_BPCraneRailTrackSplinePathSocket_HPP
#define UE4SS_SDK_BPCraneRailTrackSplinePathSocket_HPP

class UBPCraneRailTrackSplinePathSocket_C : public UBuildSocketComponent
{
};

#endif
