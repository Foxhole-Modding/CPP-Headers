#ifndef UE4SS_SDK_AvfMediaFactory_HPP
#define UE4SS_SDK_AvfMediaFactory_HPP

class UAvfMediaSettings : public UObject
{
    bool NativeAudioOut;

};

#endif
