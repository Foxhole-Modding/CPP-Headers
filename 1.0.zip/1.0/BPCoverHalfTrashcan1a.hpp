#ifndef UE4SS_SDK_BPCoverHalfTrashcan1a_HPP
#define UE4SS_SDK_BPCoverHalfTrashcan1a_HPP

class ABPCoverHalfTrashcan1a_C : public AActor
{
    class UStaticMeshComponent* StaticMesh;
    class USceneComponent* Default Scene Root;

};

#endif
