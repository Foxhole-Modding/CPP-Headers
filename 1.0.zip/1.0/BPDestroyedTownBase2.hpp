#ifndef UE4SS_SDK_BPDestroyedTownBase2_HPP
#define UE4SS_SDK_BPDestroyedTownBase2_HPP

class ABPDestroyedTownBase2_C : public ADestroyedTownHall
{
    class UStaticMeshComponent* Bollard9;
    class UStaticMeshComponent* Bollard16;
    class UStaticMeshComponent* Bollard15;
    class UStaticMeshComponent* Bollard14;
    class UStaticMeshComponent* Bollard13;
    class UStaticMeshComponent* Bollard12;
    class UStaticMeshComponent* Bollard11;
    class UStaticMeshComponent* Bollard10;
    class UStaticMeshComponent* Bollard2;
    class UStaticMeshComponent* Bollard8;
    class UStaticMeshComponent* Bollard1;
    class UStaticMeshComponent* Bollard7;
    class UStaticMeshComponent* Bollard6;
    class UStaticMeshComponent* Bollard5;
    class UStaticMeshComponent* Bollard4;
    class UStaticMeshComponent* Bollard3;
    class UStaticMeshComponent* Bollard;
    class UBoxComponent* Box;
    class UStaticMeshComponent* TownStaircase02;
    class UBPStructureInteriorArea_C* BPStructureInteriorArea2;
    class UBPStructureInteriorArea_C* BPStructureInteriorArea;
    class UBPStructureInteriorArea_C* BPStructureInteriorArea1;
    class UBPStructureInteriorArea_C* BPStructureInteriorArea3;
    class UDecalComponent* Decal4;
    class UDecalComponent* Decal3;
    class UDecalComponent* Decal2;
    class UDecalComponent* Decal1;
    class UDecalComponent* Decal;
    class UStaticMeshComponent* TownRubbleCornerIn01;
    class UStaticMeshComponent* TownRubbleFlat03;
    class UStaticMeshComponent* TownRubbleFlat02;
    class UStaticMeshComponent* TownRubbleFlat01;
    class UStaticMeshComponent* TownHallSchoolRoof_destroyed;
    class UStaticMeshComponent* TownHallSchool_destroyed;
    class UBoxComponent* NoBuildVolume;

};

#endif
