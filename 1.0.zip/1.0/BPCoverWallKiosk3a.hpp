#ifndef UE4SS_SDK_BPCoverWallKiosk3a_HPP
#define UE4SS_SDK_BPCoverWallKiosk3a_HPP

class ABPCoverWallKiosk3a_C : public AActor
{
    class UStaticMeshComponent* pumpkin01;
    class UStaticMeshComponent* StaticMesh3;
    class UStaticMeshComponent* StaticMesh2;
    class UStaticMeshComponent* StaticMesh1;
    class UStaticMeshComponent* StaticMesh;
    class UStaticMeshComponent* CoverWallKiosk3a;
    class USceneComponent* Default Scene Root;

};

#endif
