#ifndef UE4SS_SDK_BPAluminumAlloy_HPP
#define UE4SS_SDK_BPAluminumAlloy_HPP

class ABPAluminumAlloy_C : public ABasicItemPickup
{
};

#endif
