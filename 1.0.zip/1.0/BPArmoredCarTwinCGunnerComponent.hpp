#ifndef UE4SS_SDK_BPArmoredCarTwinCGunnerComponent_HPP
#define UE4SS_SDK_BPArmoredCarTwinCGunnerComponent_HPP

class UBPArmoredCarTwinCGunnerComponent_C : public UProjectileGunnerMountComponent
{
};

#endif
