#ifndef UE4SS_SDK_BPATRPGAmmoPickup_HPP
#define UE4SS_SDK_BPATRPGAmmoPickup_HPP

class ABPATRPGAmmoPickup_C : public AAmmoPickup
{
};

#endif
