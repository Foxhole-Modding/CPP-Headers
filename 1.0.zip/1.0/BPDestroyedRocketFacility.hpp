#ifndef UE4SS_SDK_BPDestroyedRocketFacility_HPP
#define UE4SS_SDK_BPDestroyedRocketFacility_HPP

class ABPDestroyedRocketFacility_C : public ADestroyedRocketFacility
{
    class UStaticMeshComponent* StaticMesh;

};

#endif
