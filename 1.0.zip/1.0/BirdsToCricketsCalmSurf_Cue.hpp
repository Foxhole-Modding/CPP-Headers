#ifndef UE4SS_SDK_BirdsToCricketsCalmSurf_Cue_HPP
#define UE4SS_SDK_BirdsToCricketsCalmSurf_Cue_HPP

class ABirdsToCricketsCalmSurf_Cue_C : public AEnvironmentSFX
{
};

#endif
