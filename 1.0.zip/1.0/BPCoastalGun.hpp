#ifndef UE4SS_SDK_BPCoastalGun_HPP
#define UE4SS_SDK_BPCoastalGun_HPP

class ABPCoastalGun_C : public ACoastalGun
{
    class UCapsuleComponent* CapsuleCollision1;
    class UCapsuleComponent* CapsuleCollision;
    class UMultiplexedSkeletalMeshComponent* MultiplexedSkeletalMesh;

};

#endif
