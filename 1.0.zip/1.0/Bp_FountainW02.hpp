#ifndef UE4SS_SDK_Bp_FountainW02_HPP
#define UE4SS_SDK_Bp_FountainW02_HPP

class ABp_FountainW02_C : public AActor
{
    class UDecalComponent* Dirt Decal8;
    class UDecalComponent* Dirt Decal7;
    class UDecalComponent* Dirt Decal6;
    class UDecalComponent* Leaves3;
    class UDecalComponent* Leaves2;
    class UDecalComponent* leaves1;
    class UDecalComponent* Dirt Decal5;
    class UDecalComponent* Dirt Decal4;
    class UDecalComponent* Dirt Decal3;
    class UDecalComponent* GourndFloor;
    class UDecalComponent* Dirtside5;
    class UDecalComponent* Dirtside4;
    class UDecalComponent* Dirtside3;
    class UDecalComponent* Dirtside2;
    class UDecalComponent* Dirt Decal2;
    class UDecalComponent* Dirt Decal1;
    class UDecalComponent* Leaves;
    class UDecalComponent* Dirtside;
    class UDecalComponent* Dirt Decal;
    class UStaticMeshComponent* FountainC01;
    class USceneComponent* DefaultSceneRoot;

};

#endif
