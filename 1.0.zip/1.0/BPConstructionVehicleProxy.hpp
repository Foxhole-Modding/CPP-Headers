#ifndef UE4SS_SDK_BPConstructionVehicleProxy_HPP
#define UE4SS_SDK_BPConstructionVehicleProxy_HPP

class ABPConstructionVehicleProxy_C : public ABuildableStructure
{
};

#endif
