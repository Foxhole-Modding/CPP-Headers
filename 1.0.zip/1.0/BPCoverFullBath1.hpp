#ifndef UE4SS_SDK_BPCoverFullBath1_HPP
#define UE4SS_SDK_BPCoverFullBath1_HPP

class ABPCoverFullBath1_C : public AActor
{
    class UStaticMeshComponent* StaticMesh;
    class USceneComponent* Default Scene Root;

};

#endif
