#ifndef UE4SS_SDK_BPBoundaryHex_HPP
#define UE4SS_SDK_BPBoundaryHex_HPP

class ABPBoundaryHex_C : public ABoundaryHex
{
};

#endif
