#ifndef UE4SS_SDK_BPComponentMineBuildSite_HPP
#define UE4SS_SDK_BPComponentMineBuildSite_HPP

class ABPComponentMineBuildSite_C : public AResourceMineBuildSite
{
    class UBoxComponent* Box3;
    class UBoxComponent* Box2;
    class UBoxComponent* Box1;
    class UBoxComponent* Box;
    class UStaticMeshComponent* StaticMesh;
    class USkeletalMeshComponent* SkeletalMesh;

};

#endif
