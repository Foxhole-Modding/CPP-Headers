#ifndef UE4SS_SDK_BPDeployedListeningKit_HPP
#define UE4SS_SDK_BPDeployedListeningKit_HPP

class ABPDeployedListeningKit_C : public ADeployedListeningKit
{
    class UAudioComponent* ListeningLoop;

};

#endif
