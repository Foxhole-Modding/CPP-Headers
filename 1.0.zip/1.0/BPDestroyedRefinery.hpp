#ifndef UE4SS_SDK_BPDestroyedRefinery_HPP
#define UE4SS_SDK_BPDestroyedRefinery_HPP

class ABPDestroyedRefinery_C : public ADestroyedRefinery
{
    class UStaticMeshComponent* StaticMesh11;
    class UStaticMeshComponent* StaticMesh10;
    class UStaticMeshComponent* StaticMesh9;
    class UStaticMeshComponent* StaticMesh8;
    class UStaticMeshComponent* StaticMesh7;
    class UStaticMeshComponent* StaticMesh6;
    class UStaticMeshComponent* StaticMesh5;
    class UStaticMeshComponent* StaticMesh4;
    class UStaticMeshComponent* StaticMesh3;
    class UStaticMeshComponent* StaticMesh2;
    class UStaticMeshComponent* StaticMesh1;
    class UStaticMeshComponent* StaticMesh;
    class UStaticMeshComponent* Barrel_01;
    class UStaticMeshComponent* Explosivepile;
    class UStaticMeshComponent* CivicMaterial;
    class UStaticMeshComponent* RefinedMaterialPickup;
    class UStaticMeshComponent* RefineryBuildingDestroyed;

};

#endif
