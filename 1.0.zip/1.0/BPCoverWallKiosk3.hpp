#ifndef UE4SS_SDK_BPCoverWallKiosk3_HPP
#define UE4SS_SDK_BPCoverWallKiosk3_HPP

class ABPCoverWallKiosk3_C : public AActor
{
    class UStaticMeshComponent* GrainSackClosed;
    class UStaticMeshComponent* Rope02;
    class UStaticMeshComponent* StaticMesh1;
    class UStaticMeshComponent* FoodCrateOpenv2;
    class UStaticMeshComponent* WoodenCrateFullApples;
    class UStaticMeshComponent* StaticMesh;
    class USceneComponent* Default Scene Root;

};

#endif
