#ifndef UE4SS_SDK_BPDestroyedCoastalGun_HPP
#define UE4SS_SDK_BPDestroyedCoastalGun_HPP

class ABPDestroyedCoastalGun_C : public ADestroyedStructure
{
    class UStaticMeshComponent* CoastalGun;

};

#endif
