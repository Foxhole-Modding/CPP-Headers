#ifndef UE4SS_SDK_BirdsToCricketsLake_Cue1_HPP
#define UE4SS_SDK_BirdsToCricketsLake_Cue1_HPP

class ABirdsToCricketsLake_Cue1_C : public AEnvironmentSFX
{
};

#endif
