#ifndef UE4SS_SDK_BPCoverHalfBath1d_HPP
#define UE4SS_SDK_BPCoverHalfBath1d_HPP

class ABPCoverHalfBath1d_C : public AActor
{
    class UStaticMeshComponent* StaticMesh;
    class USceneComponent* Default Scene Root;

};

#endif
