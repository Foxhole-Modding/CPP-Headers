#ifndef UE4SS_SDK_BPBargeBuildSite_HPP
#define UE4SS_SDK_BPBargeBuildSite_HPP

class ABPBargeBuildSite_C : public AVehicleBuildSite
{
    class UBoxComponent* Box;
    class USkeletalMeshComponent* Truck;

};

#endif
