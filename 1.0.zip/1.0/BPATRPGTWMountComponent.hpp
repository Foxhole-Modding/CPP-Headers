#ifndef UE4SS_SDK_BPATRPGTWMountComponent_HPP
#define UE4SS_SDK_BPATRPGTWMountComponent_HPP

class UBPATRPGTWMountComponent_C : public UProjectileGunnerMountComponent
{
};

#endif
