#ifndef UE4SS_SDK_BPATLargeAmmo_HPP
#define UE4SS_SDK_BPATLargeAmmo_HPP

class UBPATLargeAmmo_C : public ULargeItemComponent
{
};

#endif
