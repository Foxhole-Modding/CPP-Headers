#ifndef UE4SS_SDK_BPDestroyedGarrisonFishHut_HPP
#define UE4SS_SDK_BPDestroyedGarrisonFishHut_HPP

class ABPDestroyedGarrisonFishHut_C : public ADestroyedGarrisonHouse
{
    class URuinedMeshComponent* RuinedMesh;
    class UBPStructureInteriorArea_C* BPStructureInteriorArea;
    class UStaticMeshComponent* StaticMesh;
    class UStaticMeshComponent* StaticMesh5;
    class UStaticMeshComponent* StaticMesh4;
    class UStaticMeshComponent* StaticMesh3;
    class UStaticMeshComponent* StaticMesh2;
    class UStaticMeshComponent* StaticMesh1;
    class UStaticMeshComponent* HouseMesh;

};

#endif
