#ifndef UE4SS_SDK_BPDestroyedKeep_HPP
#define UE4SS_SDK_BPDestroyedKeep_HPP

class ABPDestroyedKeep_C : public ADestroyedKeep
{
    class UStaticMeshComponent* StaticMesh11;
    class UStaticMeshComponent* StaticMesh10;
    class UStaticMeshComponent* StaticMesh9;
    class UStaticMeshComponent* StaticMesh8;
    class UStaticMeshComponent* StaticMesh7;
    class UStaticMeshComponent* StaticMesh6;
    class UStaticMeshComponent* StaticMesh5;
    class UStaticMeshComponent* StaticMesh4;
    class UStaticMeshComponent* StaticMesh3;
    class UStaticMeshComponent* StaticMesh2;
    class UStaticMeshComponent* StaticMesh1;
    class UStaticMeshComponent* StaticMesh;
    class UBoxComponent* Box;
    class UStaticMeshComponent* Keep Mesh;

};

#endif
