#ifndef UE4SS_SDK_BPATRPGWPickup_HPP
#define UE4SS_SDK_BPATRPGWPickup_HPP

class ABPATRPGWPickup_C : public AItemPickup
{
    class USkeletalMeshComponent* SkeletalMesh;

};

#endif
