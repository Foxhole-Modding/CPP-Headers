#ifndef UE4SS_SDK_BPDeployedTripodGhost_HPP
#define UE4SS_SDK_BPDeployedTripodGhost_HPP

class ABPDeployedTripodGhost_C : public ABuildGhost
{
    class UStaticMeshComponent* StaticMesh;
    class USkeletalMeshComponent* SkeletalMesh;

};

#endif
