#ifndef UE4SS_SDK_BasicLadder2_HPP
#define UE4SS_SDK_BasicLadder2_HPP

class ABasicLadder2_C : public ALadder
{
};

#endif
