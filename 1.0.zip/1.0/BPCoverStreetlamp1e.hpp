#ifndef UE4SS_SDK_BPCoverStreetlamp1e_HPP
#define UE4SS_SDK_BPCoverStreetlamp1e_HPP

class ABPCoverStreetlamp1e_C : public AActor
{
    class UDecalComponent* Decal;
    class UStaticMeshComponent* StaticMesh;
    class USceneComponent* Default Scene Root;

};

#endif
