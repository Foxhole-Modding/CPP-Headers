#ifndef UE4SS_SDK_BPDestroyedStaticCrane_HPP
#define UE4SS_SDK_BPDestroyedStaticCrane_HPP

class ABPDestroyedStaticCrane_C : public ADestroyedStructure
{
    class UBoxComponent* Box;
    class UStaticMeshComponent* StaticMesh;

};

#endif
