#ifndef UE4SS_SDK_BPDestroyedLandingDock_HPP
#define UE4SS_SDK_BPDestroyedLandingDock_HPP

class ABPDestroyedLandingDock_C : public ADestroyedStructure
{
    class UBoxComponent* Box;
    class UStaticMeshComponent* StaticMesh;

};

#endif
