#ifndef UE4SS_SDK_BPBulwarkWallEntrance02_HPP
#define UE4SS_SDK_BPBulwarkWallEntrance02_HPP

class ABPBulwarkWallEntrance02_C : public AActor
{
    class UBoxComponent* Box;
    class UBPStructureInteriorArea_C* BPStructureInteriorArea;
    class UStaticMeshComponent* BulwarkWallRoof;
    class UStaticMeshComponent* BulwarkWallBase02;
    class USceneComponent* DefaultSceneRoot;

};

#endif
