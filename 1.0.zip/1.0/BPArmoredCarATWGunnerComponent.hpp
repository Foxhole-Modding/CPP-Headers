#ifndef UE4SS_SDK_BPArmoredCarATWGunnerComponent_HPP
#define UE4SS_SDK_BPArmoredCarATWGunnerComponent_HPP

class UBPArmoredCarATWGunnerComponent_C : public UProjectileGunnerMountComponent
{
};

#endif
