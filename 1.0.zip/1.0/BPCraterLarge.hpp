#ifndef UE4SS_SDK_BPCraterLarge_HPP
#define UE4SS_SDK_BPCraterLarge_HPP

class ABPCraterLarge_C : public ACrater
{
    class UStaticMeshComponent* CraterLarge01;
    class UDecalComponent* Decal;
    class UStaticMeshComponent* Floor;
    class UBoxComponent* Hole;

};

#endif
