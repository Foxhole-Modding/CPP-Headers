#ifndef UE4SS_SDK_BPDestroyedForwardBase1_HPP
#define UE4SS_SDK_BPDestroyedForwardBase1_HPP

class ABPDestroyedForwardBase1_C : public ADestroyedBase
{
    class UDecalComponent* Decal;
    class UDecalComponent* Decal3;
    class UDecalComponent* Decal2;
    class UDecalComponent* Decal1;
    class UStaticMeshComponent* TownHallMesh;

};

#endif
