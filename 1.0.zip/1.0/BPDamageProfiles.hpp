#ifndef UE4SS_SDK_BPDamageProfiles_HPP
#define UE4SS_SDK_BPDamageProfiles_HPP

class ABPDamageProfiles_C : public ADamageProfiles
{
    class USceneComponent* DefaultSceneRoot;

};

#endif
