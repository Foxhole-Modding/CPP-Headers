#ifndef UE4SS_SDK_BPDemolitionDamageType_HPP
#define UE4SS_SDK_BPDemolitionDamageType_HPP

class UBPDemolitionDamageType_C : public USimDamageType
{
};

#endif
