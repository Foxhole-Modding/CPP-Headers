#ifndef UE4SS_SDK_BPCalloutMarker_HPP
#define UE4SS_SDK_BPCalloutMarker_HPP

class ABPCalloutMarker_C : public ACalloutMarker
{
    class USkeletalMeshComponent* PinPoint;
    class USceneComponent* DefaultSceneRoot;

};

#endif
