#ifndef UE4SS_SDK_BPATRPGCItemComponent_HPP
#define UE4SS_SDK_BPATRPGCItemComponent_HPP

class UBPATRPGCItemComponent_C : public UProjectileItemComponent
{
};

#endif
