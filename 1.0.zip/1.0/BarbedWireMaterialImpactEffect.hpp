#ifndef UE4SS_SDK_BarbedWireMaterialImpactEffect_HPP
#define UE4SS_SDK_BarbedWireMaterialImpactEffect_HPP

class ABarbedWireMaterialImpactEffect_C : public AImpactEffect
{
    class USceneComponent* DefaultSceneRoot;

};

#endif
