#ifndef UE4SS_SDK_BPDestroyedFactory_HPP
#define UE4SS_SDK_BPDestroyedFactory_HPP

class ABPDestroyedFactory_C : public ADestroyedSpecializedFactory
{
    class UStaticMeshComponent* FactoryBasicFacility;
    class UStaticMeshComponent* StaticMesh1;
    class UDecalComponent* Decal7;
    class UDecalComponent* Decal5;
    class UDecalComponent* Decal4;
    class UDecalComponent* Decal3;
    class UDecalComponent* Decal2;
    class UDecalComponent* Decal1;
    class UDecalComponent* Decal;
    class UStaticMeshComponent* StaticMesh;

};

#endif
