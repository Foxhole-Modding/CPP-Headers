#ifndef UE4SS_SDK_BandagesPickup_HPP
#define UE4SS_SDK_BandagesPickup_HPP

class ABandagesPickup_C : public AGearPickup
{
};

#endif
