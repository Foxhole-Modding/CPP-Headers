#ifndef UE4SS_SDK_BPCoverFullBench1_HPP
#define UE4SS_SDK_BPCoverFullBench1_HPP

class ABPCoverFullBench1_C : public AActor
{
    class UDecalComponent* Decal;
    class UStaticMeshComponent* StaticMesh;
    class USceneComponent* Default Scene Root;

};

#endif
