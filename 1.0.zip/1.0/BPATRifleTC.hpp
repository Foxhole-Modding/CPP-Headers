#ifndef UE4SS_SDK_BPATRifleTC_HPP
#define UE4SS_SDK_BPATRifleTC_HPP

class ABPATRifleTC_C : public AGearPickup
{
    class USkeletalMeshComponent* SkeletalMesh;

};

#endif
