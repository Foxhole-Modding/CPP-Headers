#ifndef UE4SS_SDK_BPATRPGWProjectile_HPP
#define UE4SS_SDK_BPATRPGWProjectile_HPP

class ABPATRPGWProjectile_C : public AWarProjectile
{
    class UStaticMeshComponent* Mesh;

};

#endif
