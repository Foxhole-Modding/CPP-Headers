#ifndef UE4SS_SDK_BPCairns2_HPP
#define UE4SS_SDK_BPCairns2_HPP

class ABPCairns2_C : public AActor
{
    class UStaticMeshComponent* Cairns2;
    class USceneComponent* DefaultSceneRoot;

};

#endif
