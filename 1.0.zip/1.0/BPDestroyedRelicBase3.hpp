#ifndef UE4SS_SDK_BPDestroyedRelicBase3_HPP
#define UE4SS_SDK_BPDestroyedRelicBase3_HPP

class ABPDestroyedRelicBase3_C : public ADestroyedTownHall
{
    class UStaticMeshComponent* RelicBunkerAIShootSpotDestroyed;
    class UStaticMeshComponent* StaticMesh2;
    class UStaticMeshComponent* StaticMesh1;
    class UStaticMeshComponent* StaticMesh;
    class UStaticMeshComponent* RelicBase04Destroyed;

};

#endif
