#ifndef UE4SS_SDK_BPCoverHalfBath1c_HPP
#define UE4SS_SDK_BPCoverHalfBath1c_HPP

class ABPCoverHalfBath1c_C : public AActor
{
    class UStaticMeshComponent* StaticMesh;
    class USceneComponent* Default Scene Root;

};

#endif
