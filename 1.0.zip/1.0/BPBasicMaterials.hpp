#ifndef UE4SS_SDK_BPBasicMaterials_HPP
#define UE4SS_SDK_BPBasicMaterials_HPP

class ABPBasicMaterials_C : public ABasicItemPickup
{
};

#endif
