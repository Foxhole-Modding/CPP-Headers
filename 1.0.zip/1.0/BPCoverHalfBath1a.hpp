#ifndef UE4SS_SDK_BPCoverHalfBath1a_HPP
#define UE4SS_SDK_BPCoverHalfBath1a_HPP

class ABPCoverHalfBath1a_C : public AActor
{
    class UStaticMeshComponent* StaticMesh;
    class USceneComponent* Default Scene Root;

};

#endif
