#ifndef UE4SS_SDK_BPBattleTankGunnerMount_HPP
#define UE4SS_SDK_BPBattleTankGunnerMount_HPP

class UBPBattleTankGunnerMount_C : public UTankGunnerMountComponent
{
};

#endif
