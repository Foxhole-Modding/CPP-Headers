#ifndef UE4SS_SDK_BasicLadder_HPP
#define UE4SS_SDK_BasicLadder_HPP

class ABasicLadder_C : public ALadder
{
};

#endif
