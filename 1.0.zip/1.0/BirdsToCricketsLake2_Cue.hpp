#ifndef UE4SS_SDK_BirdsToCricketsLake2_Cue_HPP
#define UE4SS_SDK_BirdsToCricketsLake2_Cue_HPP

class ABirdsToCricketsLake2_Cue_C : public AEnvironmentSFX
{
};

#endif
