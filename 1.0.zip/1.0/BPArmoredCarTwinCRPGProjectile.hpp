#ifndef UE4SS_SDK_BPArmoredCarTwinCRPGProjectile_HPP
#define UE4SS_SDK_BPArmoredCarTwinCRPGProjectile_HPP

class ABPArmoredCarTwinCRPGProjectile_C : public AWarProjectile
{
    class UStaticMeshComponent* Mesh;

};

#endif
