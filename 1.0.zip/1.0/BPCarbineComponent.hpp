#ifndef UE4SS_SDK_BPCarbineComponent_HPP
#define UE4SS_SDK_BPCarbineComponent_HPP

class UBPCarbineComponent_C : public UGrenadeAdapterComponent
{
};

#endif
