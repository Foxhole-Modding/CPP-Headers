#ifndef UE4SS_SDK_BPAntiTankExplosiveMineDamageType_HPP
#define UE4SS_SDK_BPAntiTankExplosiveMineDamageType_HPP

class UBPAntiTankExplosiveMineDamageType_C : public USimDamageType
{
};

#endif
