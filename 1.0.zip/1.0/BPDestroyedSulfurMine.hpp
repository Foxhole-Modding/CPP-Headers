#ifndef UE4SS_SDK_BPDestroyedSulfurMine_HPP
#define UE4SS_SDK_BPDestroyedSulfurMine_HPP

class ABPDestroyedSulfurMine_C : public ADestroyedResourceMine
{
    class UDecalComponent* Decal;
    class UStaticMeshComponent* StaticMesh;

};

#endif
