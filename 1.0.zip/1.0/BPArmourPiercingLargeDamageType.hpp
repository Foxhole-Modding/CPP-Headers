#ifndef UE4SS_SDK_BPArmourPiercingLargeDamageType_HPP
#define UE4SS_SDK_BPArmourPiercingLargeDamageType_HPP

class UBPArmourPiercingLargeDamageType_C : public USimDamageType
{
};

#endif
