#ifndef UE4SS_SDK_BPAmmoUniformW_HPP
#define UE4SS_SDK_BPAmmoUniformW_HPP

class ABPAmmoUniformW_C : public ABPUniform_C
{
};

#endif
