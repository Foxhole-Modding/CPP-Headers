#ifndef UE4SS_SDK_BPCoverFullTrash2a_HPP
#define UE4SS_SDK_BPCoverFullTrash2a_HPP

class ABPCoverFullTrash2a_C : public AActor
{
    class UDecalComponent* Decal;
    class UStaticMeshComponent* StaticMesh;
    class USceneComponent* Default Scene Root;

};

#endif
