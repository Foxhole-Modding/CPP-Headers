#ifndef UE4SS_SDK_AssaultRifleHeavyW_HPP
#define UE4SS_SDK_AssaultRifleHeavyW_HPP

class UAssaultRifleHeavyW_C : public UHitScanWeaponComponent
{
};

#endif
