#ifndef UE4SS_SDK_BPCoverWallKiosk4_HPP
#define UE4SS_SDK_BPCoverWallKiosk4_HPP

class ABPCoverWallKiosk4_C : public AActor
{
    class UStaticMeshComponent* PropagandaPosterWarV1;
    class UStaticMeshComponent* Paper04;
    class UStaticMeshComponent* Books_03;
    class UStaticMeshComponent* StaticMesh3;
    class UStaticMeshComponent* StaticMesh2;
    class UStaticMeshComponent* Books_05;
    class UStaticMeshComponent* StaticMesh1;
    class UStaticMeshComponent* StaticMesh;
    class USceneComponent* Default Scene Root;

};

#endif
