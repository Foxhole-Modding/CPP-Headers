#ifndef UE4SS_SDK_BPBloodPlasmaPickUp_HPP
#define UE4SS_SDK_BPBloodPlasmaPickUp_HPP

class ABPBloodPlasmaPickUp_C : public ABasicItemPickup
{
};

#endif
