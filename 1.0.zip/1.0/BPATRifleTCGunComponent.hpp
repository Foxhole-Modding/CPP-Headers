#ifndef UE4SS_SDK_BPATRifleTCGunComponent_HPP
#define UE4SS_SDK_BPATRifleTCGunComponent_HPP

class UBPATRifleTCGunComponent_C : public UDeployableItemComponent
{
};

#endif
