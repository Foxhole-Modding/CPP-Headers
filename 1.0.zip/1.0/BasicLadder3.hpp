#ifndef UE4SS_SDK_BasicLadder3_HPP
#define UE4SS_SDK_BasicLadder3_HPP

class ABasicLadder3_C : public ALadder
{
    class UStaticMeshComponent* LadderExtension;

};

#endif
