#ifndef UE4SS_SDK_BPCoverBollard1cSouth_HPP
#define UE4SS_SDK_BPCoverBollard1cSouth_HPP

class ABPCoverBollard1cSouth_C : public AActor
{
    class UStaticMeshComponent* StaticMesh;
    class USceneComponent* Default Scene Root;

};

#endif
