#ifndef UE4SS_SDK_BirdsToCricketsGullsSurf_Cue_HPP
#define UE4SS_SDK_BirdsToCricketsGullsSurf_Cue_HPP

class ABirdsToCricketsGullsSurf_Cue_C : public AEnvironmentSFX
{
};

#endif
