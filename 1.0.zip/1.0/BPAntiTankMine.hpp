#ifndef UE4SS_SDK_BPAntiTankMine_HPP
#define UE4SS_SDK_BPAntiTankMine_HPP

class ABPAntiTankMine_C : public AMine
{
    class UBoxComponent* DismantleCollision;

};

#endif
