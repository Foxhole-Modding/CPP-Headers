#ifndef UE4SS_SDK_BPCanalStair01_300Snow_HPP
#define UE4SS_SDK_BPCanalStair01_300Snow_HPP

class ABPCanalStair01_300Snow_C : public AActor
{
    class UStaticMeshComponent* StaticMesh;
    class USceneComponent* Scene;

};

#endif
