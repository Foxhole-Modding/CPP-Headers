#ifndef UE4SS_SDK_BarbedWire04BP_HPP
#define UE4SS_SDK_BarbedWire04BP_HPP

class ABarbedWire04BP_C : public AActor
{
    class UBoxComponent* Box;
    class UStaticMeshComponent* StaticMesh;

};

#endif
