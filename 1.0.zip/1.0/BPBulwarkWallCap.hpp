#ifndef UE4SS_SDK_BPBulwarkWallCap_HPP
#define UE4SS_SDK_BPBulwarkWallCap_HPP

class ABPBulwarkWallCap_C : public AActor
{
    class UBoxComponent* Box;
    class UStaticMeshComponent* BulwarkWallCap;
    class USceneComponent* DefaultSceneRoot;

};

#endif
