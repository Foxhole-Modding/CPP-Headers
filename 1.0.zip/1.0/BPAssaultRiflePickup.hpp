#ifndef UE4SS_SDK_BPAssaultRiflePickup_HPP
#define UE4SS_SDK_BPAssaultRiflePickup_HPP

class ABPAssaultRiflePickup_C : public AFirearmPickup
{
};

#endif
