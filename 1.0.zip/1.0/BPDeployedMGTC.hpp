#ifndef UE4SS_SDK_BPDeployedMGTC_HPP
#define UE4SS_SDK_BPDeployedMGTC_HPP

class ABPDeployedMGTC_C : public ADeployedWeapon
{
    class UMultiplexedStaticMeshComponent* MultiplexedStaticMesh;

};

#endif
