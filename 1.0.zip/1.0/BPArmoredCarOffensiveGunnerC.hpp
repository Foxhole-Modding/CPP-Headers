#ifndef UE4SS_SDK_BPArmoredCarOffensiveGunnerC_HPP
#define UE4SS_SDK_BPArmoredCarOffensiveGunnerC_HPP

class UBPArmoredCarOffensiveGunnerC_C : public UHitScanMountComponent
{
};

#endif
