#ifndef UE4SS_SDK_BPCalloutMarkerGhost_HPP
#define UE4SS_SDK_BPCalloutMarkerGhost_HPP

class ABPCalloutMarkerGhost_C : public ACalloutMarkerGhost
{
    class USkeletalMeshComponent* SkeletalMesh;
    class USceneComponent* DefaultSceneRoot;

};

#endif
