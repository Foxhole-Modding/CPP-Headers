#ifndef UE4SS_SDK_BasicLadderBase_HPP
#define UE4SS_SDK_BasicLadderBase_HPP

class ABasicLadderBase_C : public ALadder
{
};

#endif
