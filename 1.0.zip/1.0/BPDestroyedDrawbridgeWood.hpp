#ifndef UE4SS_SDK_BPDestroyedDrawbridgeWood_HPP
#define UE4SS_SDK_BPDestroyedDrawbridgeWood_HPP

class ABPDestroyedDrawbridgeWood_C : public ADestroyedBridge
{
    class UStaticMeshComponent* SideB;
    class UStaticMeshComponent* SideA;

};

#endif
