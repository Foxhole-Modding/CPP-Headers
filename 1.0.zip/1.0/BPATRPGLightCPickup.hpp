#ifndef UE4SS_SDK_BPATRPGLightCPickup_HPP
#define UE4SS_SDK_BPATRPGLightCPickup_HPP

class ABPATRPGLightCPickup_C : public AFirearmPickup
{
};

#endif
