#ifndef UE4SS_SDK_BPArmoredCarGunnerComponent_HPP
#define UE4SS_SDK_BPArmoredCarGunnerComponent_HPP

class UBPArmoredCarGunnerComponent_C : public UHitScanMountComponent
{
};

#endif
