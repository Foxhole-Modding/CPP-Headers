#ifndef UE4SS_SDK_BPATRPGIndirectAmmo_HPP
#define UE4SS_SDK_BPATRPGIndirectAmmo_HPP

class ABPATRPGIndirectAmmo_C : public AAmmoPickup
{
};

#endif
