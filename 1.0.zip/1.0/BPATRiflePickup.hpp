#ifndef UE4SS_SDK_BPATRiflePickup_HPP
#define UE4SS_SDK_BPATRiflePickup_HPP

class ABPATRiflePickup_C : public AFirearmPickup
{
};

#endif
