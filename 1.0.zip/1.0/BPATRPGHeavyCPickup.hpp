#ifndef UE4SS_SDK_BPATRPGHeavyCPickup_HPP
#define UE4SS_SDK_BPATRPGHeavyCPickup_HPP

class ABPATRPGHeavyCPickup_C : public AFirearmPickup
{
};

#endif
