#ifndef UE4SS_SDK_BPCoverFullBench2aSnow_HPP
#define UE4SS_SDK_BPCoverFullBench2aSnow_HPP

class ABPCoverFullBench2aSnow_C : public AActor
{
    class UDecalComponent* Decal1;
    class UDecalComponent* Decal;
    class UStaticMeshComponent* StaticMesh;
    class USceneComponent* Default Scene Root;

};

#endif
