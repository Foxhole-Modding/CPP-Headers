#ifndef UE4SS_SDK_BPATRPGLightCProjectile_HPP
#define UE4SS_SDK_BPATRPGLightCProjectile_HPP

class ABPATRPGLightCProjectile_C : public ABPATRPGCProjectile_C
{
};

#endif
