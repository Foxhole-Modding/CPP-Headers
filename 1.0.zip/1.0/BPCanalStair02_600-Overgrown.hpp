#ifndef UE4SS_SDK_BPCanalStair02_600-Overgrown_HPP
#define UE4SS_SDK_BPCanalStair02_600-Overgrown_HPP

class ABPCanalStair02_600-Overgrown_C : public AActor
{
    class UStaticMeshComponent* Ivy26;
    class UStaticMeshComponent* Ivy25;
    class UStaticMeshComponent* Ivy24;
    class UStaticMeshComponent* Ivy23;
    class UStaticMeshComponent* Ivy22;
    class UStaticMeshComponent* Ivy21;
    class UStaticMeshComponent* Ivy20;
    class UStaticMeshComponent* Ivy19;
    class UStaticMeshComponent* Ivy18;
    class UStaticMeshComponent* Ivy17;
    class UStaticMeshComponent* Ivy15;
    class UStaticMeshComponent* StaticMesh;
    class USceneComponent* Scene;

};

#endif
