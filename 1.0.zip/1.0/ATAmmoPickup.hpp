#ifndef UE4SS_SDK_ATAmmoPickup_HPP
#define UE4SS_SDK_ATAmmoPickup_HPP

class AATAmmoPickup_C : public ATankAmmoPickup
{
};

#endif
