#ifndef UE4SS_SDK_BPArmourUniformC_HPP
#define UE4SS_SDK_BPArmourUniformC_HPP

class ABPArmourUniformC_C : public ABPUniform_C
{
};

#endif
