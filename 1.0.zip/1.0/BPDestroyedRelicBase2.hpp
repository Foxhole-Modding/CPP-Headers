#ifndef UE4SS_SDK_BPDestroyedRelicBase2_HPP
#define UE4SS_SDK_BPDestroyedRelicBase2_HPP

class ABPDestroyedRelicBase2_C : public ADestroyedTownHall
{
    class UStaticMeshComponent* StaticMesh2;
    class UStaticMeshComponent* StaticMesh1;
    class UStaticMeshComponent* StaticMesh;
    class UStaticMeshComponent* RelicBunkerShootSpotAIDestroyed;
    class UStaticMeshComponent* RelicBase03Destroyed;

};

#endif
