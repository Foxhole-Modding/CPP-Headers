#ifndef UE4SS_SDK_BPDeployedListeningKitGhost_HPP
#define UE4SS_SDK_BPDeployedListeningKitGhost_HPP

class ABPDeployedListeningKitGhost_C : public ABuildGhost
{
    class UBuildSocketComponent* BuildSocket;
    class USkeletalMeshComponent* SkeletalMesh1;
    class USkeletalMeshComponent* SkeletalMesh;

};

#endif
