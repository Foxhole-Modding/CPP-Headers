#ifndef UE4SS_SDK_BPDeployedInfantrySupportGun_HPP
#define UE4SS_SDK_BPDeployedInfantrySupportGun_HPP

class ABPDeployedInfantrySupportGun_C : public ADeployedInfantrySupportGun
{
    class UMultiplexedStaticMeshComponent* MultiplexedStaticMesh;

};

#endif
