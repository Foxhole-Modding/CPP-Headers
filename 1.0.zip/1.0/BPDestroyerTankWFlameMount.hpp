#ifndef UE4SS_SDK_BPDestroyerTankWFlameMount_HPP
#define UE4SS_SDK_BPDestroyerTankWFlameMount_HPP

class UBPDestroyerTankWFlameMount_C : public UBPFlameMountBaseComponent_C
{
};

#endif
