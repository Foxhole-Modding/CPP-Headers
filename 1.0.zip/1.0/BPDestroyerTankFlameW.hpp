#ifndef UE4SS_SDK_BPDestroyerTankFlameW_HPP
#define UE4SS_SDK_BPDestroyerTankFlameW_HPP

class ABPDestroyerTankFlameW_C : public ABPDestroyerTankBaseW_C
{
};

#endif
