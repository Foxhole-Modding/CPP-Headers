#ifndef UE4SS_SDK_BPCoverBollard1b_HPP
#define UE4SS_SDK_BPCoverBollard1b_HPP

class ABPCoverBollard1b_C : public AActor
{
    class UStaticMeshComponent* StaticMesh;
    class USceneComponent* Default Scene Root;

};

#endif
