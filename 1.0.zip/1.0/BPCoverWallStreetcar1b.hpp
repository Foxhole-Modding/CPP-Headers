#ifndef UE4SS_SDK_BPCoverWallStreetcar1b_HPP
#define UE4SS_SDK_BPCoverWallStreetcar1b_HPP

class ABPCoverWallStreetcar1b_C : public AActor
{
    class UStaticMeshComponent* CoverWallStreetcar1a;
    class USceneComponent* DefaultSceneRoot;

};

#endif
