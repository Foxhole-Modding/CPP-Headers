#ifndef UE4SS_SDK_BPCoverWallStreetcar1_HPP
#define UE4SS_SDK_BPCoverWallStreetcar1_HPP

class ABPCoverWallStreetcar1_C : public AActor
{
    class UStaticMeshComponent* CoverWallStreetcar1;
    class USceneComponent* DefaultSceneRoot;

};

#endif
