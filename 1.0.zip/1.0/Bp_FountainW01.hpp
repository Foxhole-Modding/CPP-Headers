#ifndef UE4SS_SDK_Bp_FountainW01_HPP
#define UE4SS_SDK_Bp_FountainW01_HPP

class ABp_FountainW01_C : public AActor
{
    class UDecalComponent* sidedirt1;
    class UDecalComponent* sidedirt;
    class UDecalComponent* GourndFloor1;
    class UDecalComponent* Dirt Decal10;
    class UDecalComponent* Dirt Decal9;
    class UDecalComponent* leaf2;
    class UDecalComponent* R;
    class UDecalComponent* Dirt Decal8;
    class UDecalComponent* Dirt Decal7;
    class UDecalComponent* Dirt Decal6;
    class UDecalComponent* Dirt Decal5;
    class UDecalComponent* Dirt Decal4;
    class UDecalComponent* Dirt Decal3;
    class UDecalComponent* TopDirt;
    class UDecalComponent* W;
    class UDecalComponent* GourndFloor;
    class UDecalComponent* Dirt Decal2;
    class UDecalComponent* Dirt Decal1;
    class UDecalComponent* Dirt Decal;
    class UStaticMeshComponent* FountainC01;
    class USceneComponent* DefaultSceneRoot;

};

#endif
