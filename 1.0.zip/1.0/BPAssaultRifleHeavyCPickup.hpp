#ifndef UE4SS_SDK_BPAssaultRifleHeavyCPickup_HPP
#define UE4SS_SDK_BPAssaultRifleHeavyCPickup_HPP

class ABPAssaultRifleHeavyCPickup_C : public AFirearmPickup
{
};

#endif
