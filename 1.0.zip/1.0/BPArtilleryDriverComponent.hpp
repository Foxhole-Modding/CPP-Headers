#ifndef UE4SS_SDK_BPArtilleryDriverComponent_HPP
#define UE4SS_SDK_BPArtilleryDriverComponent_HPP

class UBPArtilleryDriverComponent_C : public UMountComponent
{
};

#endif
