#ifndef UE4SS_SDK_BirdsToCrickets2_Cue_HPP
#define UE4SS_SDK_BirdsToCrickets2_Cue_HPP

class ABirdsToCrickets2_Cue_C : public AEnvironmentSFX
{
};

#endif
