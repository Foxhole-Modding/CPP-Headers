#ifndef UE4SS_SDK_BirdsToCrickets1_Cue_HPP
#define UE4SS_SDK_BirdsToCrickets1_Cue_HPP

class ABirdsToCrickets1_Cue_C : public AEnvironmentSFX
{
};

#endif
