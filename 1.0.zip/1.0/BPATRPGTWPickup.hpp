#ifndef UE4SS_SDK_BPATRPGTWPickup_HPP
#define UE4SS_SDK_BPATRPGTWPickup_HPP

class ABPATRPGTWPickup_C : public AGearPickup
{
    class USkeletalMeshComponent* SkeletalMesh;

};

#endif
