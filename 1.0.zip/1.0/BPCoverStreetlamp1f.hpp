#ifndef UE4SS_SDK_BPCoverStreetlamp1f_HPP
#define UE4SS_SDK_BPCoverStreetlamp1f_HPP

class ABPCoverStreetlamp1f_C : public AActor
{
    class UDecalComponent* Decal;
    class UStaticMeshComponent* StaticMesh;
    class USceneComponent* Default Scene Root;

};

#endif
