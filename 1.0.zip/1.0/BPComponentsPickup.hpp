#ifndef UE4SS_SDK_BPComponentsPickup_HPP
#define UE4SS_SDK_BPComponentsPickup_HPP

class ABPComponentsPickup_C : public ABasicItemPickup
{
};

#endif
