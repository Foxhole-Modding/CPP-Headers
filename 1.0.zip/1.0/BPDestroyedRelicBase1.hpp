#ifndef UE4SS_SDK_BPDestroyedRelicBase1_HPP
#define UE4SS_SDK_BPDestroyedRelicBase1_HPP

class ABPDestroyedRelicBase1_C : public ADestroyedTownHall
{
    class UStaticMeshComponent* StaticMesh1;
    class UStaticMeshComponent* StaticMesh;
    class UStaticMeshComponent* RelicBunkerShootSpotAIDestroyed;
    class UStaticMeshComponent* RelicBase02AIDestroyed;

};

#endif
