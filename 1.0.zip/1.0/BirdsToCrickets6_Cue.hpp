#ifndef UE4SS_SDK_BirdsToCrickets6_Cue_HPP
#define UE4SS_SDK_BirdsToCrickets6_Cue_HPP

class ABirdsToCrickets6_Cue_C : public AEnvironmentSFX
{
};

#endif
