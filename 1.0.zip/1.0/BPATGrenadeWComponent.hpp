#ifndef UE4SS_SDK_BPATGrenadeWComponent_HPP
#define UE4SS_SDK_BPATGrenadeWComponent_HPP

class UBPATGrenadeWComponent_C : public UGrenadeItemComponent
{
};

#endif
