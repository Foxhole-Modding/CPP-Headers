#ifndef UE4SS_SDK_BirdsToCricketsCreek_Cue_HPP
#define UE4SS_SDK_BirdsToCricketsCreek_Cue_HPP

class ABirdsToCricketsCreek_Cue_C : public AEnvironmentSFX
{
};

#endif
