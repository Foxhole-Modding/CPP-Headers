#ifndef UE4SS_SDK_BPCriticalSoldierPickUp_HPP
#define UE4SS_SDK_BPCriticalSoldierPickUp_HPP

class ABPCriticalSoldierPickUp_C : public ASoldierItemPickUp
{
};

#endif
