#ifndef UE4SS_SDK_BPATLargeAmmoPickup_HPP
#define UE4SS_SDK_BPATLargeAmmoPickup_HPP

class ABPATLargeAmmoPickup_C : public ATankAmmoPickup
{
    class USkeletalMeshComponent* ItemMeshSK;

};

#endif
