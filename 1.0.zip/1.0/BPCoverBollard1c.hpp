#ifndef UE4SS_SDK_BPCoverBollard1c_HPP
#define UE4SS_SDK_BPCoverBollard1c_HPP

class ABPCoverBollard1c_C : public AActor
{
    class UStaticMeshComponent* StaticMesh;
    class USceneComponent* Default Scene Root;

};

#endif
