#ifndef UE4SS_SDK_BombStorage02_HPP
#define UE4SS_SDK_BombStorage02_HPP

class ABombStorage02_C : public AActor
{
    class UDecalComponent* Decal4;
    class UDecalComponent* Decal3;
    class UDecalComponent* Decal2;
    class UDecalComponent* Decal1;
    class UDecalComponent* Decal;
    class UStaticMeshComponent* BasicCrates015;
    class UStaticMeshComponent* BasicCrates014;
    class UStaticMeshComponent* BasicCrates013;
    class UStaticMeshComponent* BasicCrates012;
    class UStaticMeshComponent* BasicCrates011;
    class UStaticMeshComponent* BasicCrates010;
    class UStaticMeshComponent* BasicCrates08;
    class UStaticMeshComponent* BasicCrates07;
    class UStaticMeshComponent* BasicCrates06;
    class UStaticMeshComponent* BasicCrates04;
    class UStaticMeshComponent* BasicCrates03;
    class UStaticMeshComponent* BasicCrates05;
    class UStaticMeshComponent* Ivy025;
    class UStaticMeshComponent* Ivy023;
    class UStaticMeshComponent* Ivy022;
    class UStaticMeshComponent* Ivy031;
    class UStaticMeshComponent* Ivy020;
    class UStaticMeshComponent* Ivy019;
    class UStaticMeshComponent* Ivy018;
    class UStaticMeshComponent* Ivy017;
    class UStaticMeshComponent* Ivy011;
    class UStaticMeshComponent* Ivy027;
    class UStaticMeshComponent* Ivy021;
    class UStaticMeshComponent* Ivy016;
    class UStaticMeshComponent* Ivy015;
    class UStaticMeshComponent* Ivy014;
    class UStaticMeshComponent* Ivy013;
    class UStaticMeshComponent* BasicCrates09;
    class UStaticMeshComponent* BasicCrates02;
    class UStaticMeshComponent* Palette01;
    class UStaticMeshComponent* Ivy010;
    class UStaticMeshComponent* RockShorlineCliffIvy3;
    class UStaticMeshComponent* RockShorlineCliffIvy2;
    class UStaticMeshComponent* RockShorlineMeduimv12;
    class UStaticMeshComponent* RockShorlineMeduimv11;
    class UStaticMeshComponent* RockShorlineMeduimv10;
    class UStaticMeshComponent* RockShorlineMeduimv9;
    class UStaticMeshComponent* Palette010;
    class UStaticMeshComponent* Palette08;
    class UStaticMeshComponent* Palette07;
    class UStaticMeshComponent* Palette03;
    class UStaticMeshComponent* RockShorlineMeduimv8;
    class UStaticMeshComponent* RockShorlineMeduimv7;
    class UStaticMeshComponent* RockShorlineCliffLayer;
    class UStaticMeshComponent* RockShorlineMeduimv5;
    class UStaticMeshComponent* RockShorlineCliffIvy1;
    class UStaticMeshComponent* RockShorlineCliffIvy;
    class UStaticMeshComponent* RockShorlineMeduimv4;
    class UStaticMeshComponent* RockShorlineMeduimv3;
    class UStaticMeshComponent* RockShorlineMeduimv2;
    class UStaticMeshComponent* BombStorage03;
    class USceneComponent* DefaultSceneRoot;

};

#endif
