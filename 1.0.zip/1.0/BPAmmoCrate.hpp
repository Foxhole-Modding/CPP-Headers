#ifndef UE4SS_SDK_BPAmmoCrate_HPP
#define UE4SS_SDK_BPAmmoCrate_HPP

class ABPAmmoCrate_C : public AActor
{
    class UStaticMeshComponent* StaticMesh;
    class USceneComponent* Scene;
    class UStaticMeshComponent* AmmoCrate;

};

#endif
