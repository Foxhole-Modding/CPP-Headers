#ifndef UE4SS_SDK_BPCoverStreetlamp1aSouth_HPP
#define UE4SS_SDK_BPCoverStreetlamp1aSouth_HPP

class ABPCoverStreetlamp1aSouth_C : public AActor
{
    class UDecalComponent* Decal;
    class UBoxComponent* Box;
    class UBoxComponent* Box2;
    class UBoxComponent* Box1;
    class UStaticMeshComponent* StaticMesh;
    class USceneComponent* Default Scene Root;
    class UPointLightComponent* PointLight;

};

#endif
