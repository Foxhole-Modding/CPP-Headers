#ifndef UE4SS_SDK_BPDestroyedGarrisonFishHut2_HPP
#define UE4SS_SDK_BPDestroyedGarrisonFishHut2_HPP

class ABPDestroyedGarrisonFishHut2_C : public ADestroyedGarrisonHouse
{
    class URuinedMeshComponent* RuinedMesh1;
    class URuinedMeshComponent* RuinedMesh;
    class UStaticMeshComponent* StaticMesh;
    class UStaticMeshComponent* HouseMesh;

};

#endif
