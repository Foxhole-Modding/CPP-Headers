#ifndef UE4SS_SDK_BPCoverFullBench3_HPP
#define UE4SS_SDK_BPCoverFullBench3_HPP

class ABPCoverFullBench3_C : public AActor
{
    class UDecalComponent* Decal;
    class UStaticMeshComponent* StaticMesh;
    class USceneComponent* Default Scene Root;

};

#endif
