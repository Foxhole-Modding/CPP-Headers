#ifndef UE4SS_SDK_BPCopper_HPP
#define UE4SS_SDK_BPCopper_HPP

class ABPCopper_C : public ABasicItemPickup
{
};

#endif
