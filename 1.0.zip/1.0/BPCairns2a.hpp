#ifndef UE4SS_SDK_BPCairns2a_HPP
#define UE4SS_SDK_BPCairns2a_HPP

class ABPCairns2a_C : public AActor
{
    class UStaticMeshComponent* LanternHanging2Ceiling;
    class UStaticMeshComponent* StaticMesh3;
    class UStaticMeshComponent* Log01;
    class UStaticMeshComponent* StaticMesh2;
    class UStaticMeshComponent* StaticMesh1;
    class UStaticMeshComponent* StaticMesh;
    class UStaticMeshComponent* WoodChunk01;
    class UStaticMeshComponent* Cairns2;
    class USceneComponent* DefaultSceneRoot;

};

#endif
