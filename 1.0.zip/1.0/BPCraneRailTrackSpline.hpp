#ifndef UE4SS_SDK_BPCraneRailTrackSpline_HPP
#define UE4SS_SDK_BPCraneRailTrackSpline_HPP

class ABPCraneRailTrackSpline_C : public ARailwayTrack
{
};

#endif
