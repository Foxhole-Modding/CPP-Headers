#ifndef UE4SS_SDK_BPBarbedWireMaterialsComponent_HPP
#define UE4SS_SDK_BPBarbedWireMaterialsComponent_HPP

class UBPBarbedWireMaterialsComponent_C : public ULargeMaterialComponent
{
};

#endif
