#ifndef UE4SS_SDK_BPDeployedInfantrySupportGunGhost_HPP
#define UE4SS_SDK_BPDeployedInfantrySupportGunGhost_HPP

class ABPDeployedInfantrySupportGunGhost_C : public ABuildGhost
{
    class UBuildSocketComponent* BuildSocket;
    class USkeletalMeshComponent* SkeletalMesh1;
    class UStaticMeshComponent* StaticMesh;
    class USkeletalMeshComponent* SkeletalMesh;

};

#endif
