#ifndef UE4SS_SDK_BPBusWarden_HPP
#define UE4SS_SDK_BPBusWarden_HPP

class ABPBusWarden_C : public ABPBus_C
{
};

#endif
