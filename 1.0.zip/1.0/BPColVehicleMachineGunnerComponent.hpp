#ifndef UE4SS_SDK_BPColVehicleMachineGunnerComponent_HPP
#define UE4SS_SDK_BPColVehicleMachineGunnerComponent_HPP

class UBPColVehicleMachineGunnerComponent_C : public UHitScanMountComponent
{
};

#endif
