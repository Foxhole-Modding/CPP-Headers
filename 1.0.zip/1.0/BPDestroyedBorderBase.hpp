#ifndef UE4SS_SDK_BPDestroyedBorderBase_HPP
#define UE4SS_SDK_BPDestroyedBorderBase_HPP

class ABPDestroyedBorderBase_C : public ADestroyedBorderBase
{
    class UBoxComponent* NoBuildVolume;
    class UStaticMeshComponent* TownHallMesh;

};

#endif
