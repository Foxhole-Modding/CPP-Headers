#ifndef UE4SS_SDK_BPATRPGCPickup_HPP
#define UE4SS_SDK_BPATRPGCPickup_HPP

class ABPATRPGCPickup_C : public AFirearmPickup
{
};

#endif
