#ifndef UE4SS_SDK_BPBulwarkWall00_HPP
#define UE4SS_SDK_BPBulwarkWall00_HPP

class ABPBulwarkWall00_C : public AActor
{
    class UBoxComponent* Box;
    class UStaticMeshComponent* BulwarkWallBase01;
    class USceneComponent* DefaultSceneRoot;

};

#endif
