#ifndef UE4SS_SDK_BPArmourProfiles_HPP
#define UE4SS_SDK_BPArmourProfiles_HPP

class ABPArmourProfiles_C : public AArmourProfiles
{
    class USceneComponent* DefaultSceneRoot;

};

#endif
