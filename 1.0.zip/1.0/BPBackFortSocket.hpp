#ifndef UE4SS_SDK_BPBackFortSocket_HPP
#define UE4SS_SDK_BPBackFortSocket_HPP

class UBPBackFortSocket_C : public UBuildSocketComponent
{
};

#endif
