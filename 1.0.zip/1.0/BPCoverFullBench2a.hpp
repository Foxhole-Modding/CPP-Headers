#ifndef UE4SS_SDK_BPCoverFullBench2a_HPP
#define UE4SS_SDK_BPCoverFullBench2a_HPP

class ABPCoverFullBench2a_C : public AActor
{
    class UDecalComponent* Decal1;
    class UDecalComponent* Decal;
    class UStaticMeshComponent* StaticMesh;
    class USceneComponent* Default Scene Root;

};

#endif
