#ifndef UE4SS_SDK_BPDestroyedMassProductionFactory_HPP
#define UE4SS_SDK_BPDestroyedMassProductionFactory_HPP

class ABPDestroyedMassProductionFactory_C : public ADestroyedMassProductionFactory
{
    class UStaticMeshComponent* StaticMesh9;
    class UStaticMeshComponent* StaticMesh8;
    class UStaticMeshComponent* StaticMesh7;
    class UStaticMeshComponent* StaticMesh6;
    class UStaticMeshComponent* StaticMesh5;
    class UStaticMeshComponent* StaticMesh4;
    class UStaticMeshComponent* StaticMesh3;
    class UStaticMeshComponent* StaticMesh2;
    class UStaticMeshComponent* StaticMesh1;
    class UStaticMeshComponent* StaticMesh;
    class UStaticMeshComponent* MassProductionFactory;

};

#endif
