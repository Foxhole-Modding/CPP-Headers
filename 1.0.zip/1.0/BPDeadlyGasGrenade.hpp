#ifndef UE4SS_SDK_BPDeadlyGasGrenade_HPP
#define UE4SS_SDK_BPDeadlyGasGrenade_HPP

class ABPDeadlyGasGrenade_C : public ADeadlyGasGrenadeProjectile
{
    class UStaticMeshComponent* ProjectileMesh;

};

#endif
