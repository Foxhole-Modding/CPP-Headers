#ifndef UE4SS_SDK_BPCrudeOilPickup_HPP
#define UE4SS_SDK_BPCrudeOilPickup_HPP

class ABPCrudeOilPickup_C : public ABasicItemPickup
{
};

#endif
