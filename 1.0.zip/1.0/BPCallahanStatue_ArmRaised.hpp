#ifndef UE4SS_SDK_BPCallahanStatue_ArmRaised_HPP
#define UE4SS_SDK_BPCallahanStatue_ArmRaised_HPP

class ABPCallahanStatue_ArmRaised_C : public AActor
{
    class UStaticMeshComponent* StaticMesh;
    class UStaticMeshComponent* Head;
    class UDecalComponent* Decal;
    class UStaticMeshComponent* StaticMesh10;
    class UStaticMeshComponent* StaticMesh9;
    class UStaticMeshComponent* StaticMesh8;
    class UStaticMeshComponent* StaticMesh1;
    class UStaticMeshComponent* StaticMesh7;
    class UStaticMeshComponent* StaticMesh6;
    class UStaticMeshComponent* StaticMesh5;
    class UStaticMeshComponent* StaticMesh4;
    class UStaticMeshComponent* StaticMesh3;
    class UStaticMeshComponent* StaticMesh2;
    class UStaticMeshComponent* Pitcher;
    class UStaticMeshComponent* Body;
    class USceneComponent* Scene;

};

#endif
