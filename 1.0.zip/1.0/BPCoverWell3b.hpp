#ifndef UE4SS_SDK_BPCoverWell3b_HPP
#define UE4SS_SDK_BPCoverWell3b_HPP

class ABPCoverWell3b_C : public AStaticMeshActor
{
    class UWaterReloadSourceComponent* WaterReloadSource;

};

#endif
