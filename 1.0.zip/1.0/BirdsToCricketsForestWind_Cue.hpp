#ifndef UE4SS_SDK_BirdsToCricketsForestWind_Cue_HPP
#define UE4SS_SDK_BirdsToCricketsForestWind_Cue_HPP

class ABirdsToCricketsForestWind_Cue_C : public AEnvironmentSFX
{
};

#endif
