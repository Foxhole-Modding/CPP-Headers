#ifndef UE4SS_SDK_BPATGrenadeWPickup_HPP
#define UE4SS_SDK_BPATGrenadeWPickup_HPP

class ABPATGrenadeWPickup_C : public AGrenadeWPickup_C
{
};

#endif
