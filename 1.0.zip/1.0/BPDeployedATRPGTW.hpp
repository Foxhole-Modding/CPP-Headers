#ifndef UE4SS_SDK_BPDeployedATRPGTW_HPP
#define UE4SS_SDK_BPDeployedATRPGTW_HPP

class ABPDeployedATRPGTW_C : public ADeployedWeapon
{
    class UMultiplexedStaticMeshComponent* MultiplexedStaticMesh;

};

#endif
