#ifndef UE4SS_SDK_BPCoverWallKiosk2_HPP
#define UE4SS_SDK_BPCoverWallKiosk2_HPP

class ABPCoverWallKiosk2_C : public AActor
{
    class UStaticMeshComponent* Books_03;
    class UStaticMeshComponent* Books_07;
    class UStaticMeshComponent* StaticMesh1;
    class UStaticMeshComponent* CrateGrey;
    class UStaticMeshComponent* Paper01;
    class UStaticMeshComponent* PropagandaPosterWarV2;
    class UStaticMeshComponent* Paper02;
    class UStaticMeshComponent* Lantern;
    class UStaticMeshComponent* TobaccoPickup;
    class UStaticMeshComponent* PropagandaPosterWarV1;
    class UStaticMeshComponent* StaticMesh;
    class USceneComponent* Default Scene Root;

};

#endif
