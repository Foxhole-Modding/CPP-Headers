#ifndef UE4SS_SDK_BPATGrenadeW_HPP
#define UE4SS_SDK_BPATGrenadeW_HPP

class ABPATGrenadeW_C : public AWarProjectile
{
    class UStaticMeshComponent* GrenadeMesh;

};

#endif
