#ifndef UE4SS_SDK_BPConcreteBridge_HPP
#define UE4SS_SDK_BPConcreteBridge_HPP

class ABPConcreteBridge_C : public ABridge
{
    class UDecalComponent* Decal8;
    class UDecalComponent* Decal7;
    class UDecalComponent* Decal6;
    class UDecalComponent* Decal5;
    class UMultiplexedStaticMeshComponent* MultiplexedStaticMesh;
    class UDecalComponent* Decal2;
    class UDecalComponent* Decal1;
    class UDecalComponent* W;
    class UDecalComponent* Decal4;
    class UDecalComponent* Decal3;
    class UDecalComponent* Decal;
    class UStaticMeshComponent* BridgeMesh;

};

#endif
