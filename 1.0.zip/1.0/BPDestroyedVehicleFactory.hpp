#ifndef UE4SS_SDK_BPDestroyedVehicleFactory_HPP
#define UE4SS_SDK_BPDestroyedVehicleFactory_HPP

class ABPDestroyedVehicleFactory_C : public ADestroyedVehicleFactory
{
    class UStaticMeshComponent* StaticMesh;

};

#endif
