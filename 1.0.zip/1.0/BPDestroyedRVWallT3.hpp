#ifndef UE4SS_SDK_BPDestroyedRVWallT3_HPP
#define UE4SS_SDK_BPDestroyedRVWallT3_HPP

class ABPDestroyedRVWallT3_C : public ADestroyedStructure
{
    class UStaticMeshComponent* StaticMesh;

};

#endif
