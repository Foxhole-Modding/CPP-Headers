#ifndef UE4SS_SDK_BPAmmoRoomLayout_HPP
#define UE4SS_SDK_BPAmmoRoomLayout_HPP

class UBPAmmoRoomLayout_C : public UBPBaseResourceLayout_C
{
};

#endif
