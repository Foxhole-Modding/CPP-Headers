#ifndef UE4SS_SDK_BPCopperAlloy_HPP
#define UE4SS_SDK_BPCopperAlloy_HPP

class ABPCopperAlloy_C : public ABasicItemPickup
{
};

#endif
