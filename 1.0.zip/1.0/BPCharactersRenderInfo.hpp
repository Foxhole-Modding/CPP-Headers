#ifndef UE4SS_SDK_BPCharactersRenderInfo_HPP
#define UE4SS_SDK_BPCharactersRenderInfo_HPP

class ABPCharactersRenderInfo_C : public ACharactersRenderInfo
{
    class USceneComponent* DefaultSceneRoot;

};

#endif
