#ifndef UE4SS_SDK_BattleTankAmmoPickup_HPP
#define UE4SS_SDK_BattleTankAmmoPickup_HPP

class ABattleTankAmmoPickup_C : public ATankAmmoPickup
{
    class USkeletalMeshComponent* ItemMeshSK;

};

#endif
