#ifndef UE4SS_SDK_BPBattleTankATCEngineerComponent_HPP
#define UE4SS_SDK_BPBattleTankATCEngineerComponent_HPP

class UBPBattleTankATCEngineerComponent_C : public UTankEngineerComponent
{
};

#endif
